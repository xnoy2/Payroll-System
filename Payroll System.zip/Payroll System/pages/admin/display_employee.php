<?php
  require_once("connect.php");
  $user_id = $_SESSION['user_id'];
  $sql="SELECT tbl_employee.emp_id,tbl_employee.employee_id,tbl_employee.fullname as f_name, tbl_employee.salary, tbl_department.dept_id,tbl_department.dept_name,tbl_position.position_id,tbl_position.position_name as p_name,tbl_user.user_id,tbl_user.fullname FROM tbl_employee INNER JOIN tbl_department ON tbl_employee.dept_id=tbl_department.dept_id INNER JOIN tbl_position ON tbl_employee.position_id=tbl_position.position_id INNER JOIN tbl_user ON tbl_employee.user_id=tbl_user.user_id";
  $qry=$DbConnect->prepare($sql);
  $qry->bind_result($emp_id,$employee_id,$f_name,$salary,$dept_id,$dept_name,$position_id,$p_name,$user_id,$fullname);
  $qry->execute();

  while ($qry->fetch())
  {
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT user_id,fullname FROM tbl_user WHERE user_id=?";
      ?>

      <tr>
      
        <td><b style="color: maroon"><?php echo $employee_id; ?><b style="color: darkblue"> </td>
        <td><?php echo $f_name; ?> </td>
        <td><?php echo $dept_name; ?> </td>
        <td><?php echo $p_name; ?> </td>
        <td><i><b style="color: black"><?php echo "P ".$salary; ?></b> </i></td>
        <td><?php echo $fullname; ?> </td>
         <td>
        <button type='button' class='btn btn-info btn-xs' data-toggle='modal' data-target='#update<?php echo $emp_id; ?>'><i class='fa fa-pencil-alt'></i> 
              </button>
               <button type='button' class='btn btn-xs btn-danger ' data-toggle='modal' data-target='#delete<?php echo $emp_id; ?>'><i class="fa fa-trash "></i>  </button>
        </td>
              
      </tr>
      
                  <div class="modal fade" id="update<?php echo $emp_id;?>">
                        <div class="modal-dialog modal-md">
                            <form action="" method="post" id="form1<?php echo $emp_id; ?>"  name="form1">
                         <input type="hidden" name="emp_idz" value="<?php echo $emp_id; ?>">
                         <input type="hidden" name="user_idz" value="<?php echo $user_id; ?>">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title">Update Employee</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="card card-primary">
                              <div class="modal-body">
                      <div class="form-group">
                            <label for="exampleInputEmail1">Employee ID</label>
                            <input type="text" class="form-control" id="" required name="employee_id" value="<?php echo $employee_id;?>">
                      </div>
                          <div class="form-group">
                            <label for="exampleInputEmail1">Fullname</label>
                            <input type="text" class="form-control" id="" required name="fullname" value="<?php echo $fullname;?>">
                          </div>
                          <div class="form-group">
                                  <label>Department</label>
                                  <select class="form-control select2bs4" name="dept_id" required="">
                                    <option selected value="<?php echo $dept_id ?>" ><?php echo $dept_name ?></option>
                                    <?php
                                    include 'connect.php';
                                    $sql="SELECT tbl_department.dept_id,tbl_department.dept_name FROM tbl_department ORDER BY tbl_department.dept_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($dept_id,$dept_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $dept_id ?>" ><?php echo $dept_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                                <div class="form-group">
                                  <label>Position</label>
                                  <select class="form-control select2bs4" name="position_id" required="">
                                    <option selected value="<?php echo $position_id ?>"><?php echo $position_name ?></option>
                                    <?php
                                    include 'connect.php';
                                    $sql="SELECT tbl_position.position_id,tbl_position.position_name FROM tbl_position ORDER BY tbl_position.position_name ASC";
                                    $qry=$DbConnect->prepare($sql);
                                    $qry->bind_result($position_id,$position_name);
                                    $qry->execute();

                                    while ($qry->fetch())
                                    {
                                        ?>
                                        <option value="<?php echo $position_id ?>"><?php echo $position_name ?></option>
                                  <?php 
                                    }   
                                    
                                  ?>

                                  </select>
                                </div>
                    <div class="form-group">
                            <label for="exampleInputEmail1">Salary</label>
                            <input type="number" class="form-control" required name="salary" id="" value="<?php echo $salary; ?>">
                      </div>
                      </div>
                          </div>
                            <div class="modal-footer justify-content-between">
                              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                              <button type="submit" onclick="form1<?php echo $emp_id; ?>.submit();" form="form1" class="btn btn-primary"><i class="fa fa-check"></i> Update</button>
                            </div>
                          </div>
                          </form>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                      <div class="modal fade" id="delete<?php echo $emp_id;?>" style="margin-left: 30%; margin-top: 20%">
         <div class="modal-dialog modal-sm">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Are you sure you want delete this data?</h5>
              
            </div>
            
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> No!</button>
              <a href="delete_employee.php? emp_id=<?php echo $emp_id; ?>"><button type="button" class="btn btn-primary"><i class="fa fa-check"></i> Yes!</button></a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
         

        
          
<?php 
  }   
  
?>