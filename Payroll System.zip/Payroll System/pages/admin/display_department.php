<?php
  require_once("connect.php");
  $user_id = $_SESSION['user_id'];
  $sql="SELECT tbl_department.dept_id,tbl_department.dept_name,tbl_user.user_id,tbl_user.fullname FROM tbl_department INNER JOIN tbl_user ON tbl_department.user_id=tbl_user.user_id";
  $qry=$DbConnect->prepare($sql);
  $qry->bind_result($dept_id,$dept_name,$user_id,$fullname);
  $qry->execute();

  while ($qry->fetch())
  {
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT user_id,fullname FROM tbl_user WHERE user_id=?";
      ?>

      <tr>
      
        <td><b style="color: maroon"><?php echo $dept_name; ?><b style="color: darkblue"> </td>
        <td><?php echo $fullname; ?> </td>
         <td>
        <button type='button' class='btn btn-info btn-xs' data-toggle='modal' data-target='#update<?php echo $dept_id; ?>'><i class='fa fa-pencil-alt'></i> 
              </button>
               <button type='button' class='btn btn-xs btn-danger ' data-toggle='modal' data-target='#delete<?php echo $dept_id; ?>'><i class="fa fa-trash "></i>  </button>
        </td>
              
      </tr>
      
                  <div class="modal fade" id="update<?php echo $dept_id;?>">
                        <div class="modal-dialog modal-sm">
                            <form action="update_department.php" method="post" id="form1<?php echo $dept_id; ?>"  name="form1">
                         <input type="hidden" name="dept_idz" value="<?php echo $dept_id; ?>">
                         <input type="hidden" name="user_idz" value="<?php echo $user_id; ?>">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title">Update Department</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="card card-primary">
                              <div class="card-body">
                                <div class="form-group">
                                  <label for="exampleInputEmail1">Department</label>
                                  <input type="text" class="form-control" id="" name="dept_name"  value="<?php echo $dept_name; ?>">
                                </div>
                              </div>
                          </div>
                            <div class="modal-footer justify-content-between">
                              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> Close</button>
                              <button type="submit" onclick="form1<?php echo $dept_id; ?>.submit();" form="form1" class="btn btn-primary"><i class="fa fa-check"></i> Update</button>
                            </div>
                          </div>
                          </form>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                      <div class="modal fade" id="delete<?php echo $dept_id;?>" style="margin-left: 30%; margin-top: 20%">
         <div class="modal-dialog modal-sm">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Are you sure you want delete this data?</h5>
              
            </div>
            
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> No!</button>
              <a href="delete_department.php? dept_id=<?php echo $dept_id; ?>"><button type="button" class="btn btn-primary"><i class="fa fa-check"></i> Yes!</button></a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
         

        
          
<?php 
  }   
  
?>