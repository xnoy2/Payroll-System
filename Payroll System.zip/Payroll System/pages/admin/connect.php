<?php

$Dbhost="localhost";
$DbUsername="root";
$DbPassword="";
$Dbname="payrollsystemdb";
$DbConnect=new mysqli ($Dbhost, $DbUsername, $DbPassword, $Dbname);
?>