<?php
    require_once "../../connection/connect.php";
 $sql7 = "SELECT payroll_id, serial_no, name, position, reg_salary, amt_earned, pera, gross_amt, abs_w_o_pay, life_insurrance, pagibig_cont, philhealth, withholding_tax, deped_prov_loan, gsis_gfal, gsis_help, ucpb_loan`, `eastwest_loan`, `chinabank_loan`, `csb_loan`, `bdo_loan`, `pbb_loan, `lbp_loan`, `first_total_deduc`, `first_net_amt_due`, `sc_gsis_con_loan`, `sc_gsis_eml`, `sc_gsis_policy`, `sc_gsis_help`, `sc_gsis_gfal`, `sc_gsis_mpl`, `sc_gsis_computer`, `sc_pagibig_mpl`, `sc_pagibig_savings`, `sc_csb_loan`, `sc_ucpb_loan`, `sc_chinabank_loan`, `sc_eastwest_loan`, `sc_bdo_loan`, `sc_lbp_loan`, `sc_total_deduction`, `sc_net_amt_due`, `month`, `year` FROM tbl_equipment INNER JOIN tbl_borrowed ON tbl_equipment.equipment_id = 
tbl_borrowed.equipment_id WHERE tbl_borrowed.status = 1 OR tbl_borrowed.status= 2 GROUP BY tbl_equipment.code ASC LIMIT 20";
    $qry7=$DbConnect->prepare($sql7);
    $qry7->bind_result($equipment_id,$equipment_name,$quantity,$code,$avatar,$req_quan,$ret_quan,$dam_quan,$remaining,$total_borrowed);
    $qry7->execute();
    
    $data1;
    $data2;
    $row = 0;

    while ($qry7->fetch())
    {
         $data2[$row] = $req_quan;
            $data1[$row] = $equipment_name;
 
        $row++;
    }
    $color = array("#FF0F00","#FF6600","#FF9E01","#FCD202","#F8FF01","#B0DE09","#04D215","#0D8ECF","#0D52D1","#2A0CD0","#8A0CCF","#CD0D74","#754DEB","#DDDDDD","#999999","#333333");
   
     $charData= '';
    for ($i = 0; $i < $row; $i++)
    {
        $charData .= " {equipment:'".$data1[$i]."', level:".$data2[$i].", color:'". $color[$i]."'}, ";
        
        
    }
    $charData = substr ($charData, 0, -2);
    $charData = "[".$charData."];";
    
    $qry7->close();
    $DbConnect->close();
?>