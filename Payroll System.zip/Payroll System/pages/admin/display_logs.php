<?php
  require_once("connect.php");
 
  $sql="SELECT `name`,`count_print`, `date_printed` FROM tbl_payroll";
  $qry=$DbConnect->prepare($sql);
  $qry->bind_result($name,$count_print,$date_printed);
  $qry->execute();

  while ($qry->fetch())
  {
    
      ?>

      <tr>
      
        <td><b style="color: maroon"><?php echo $name; ?><b style="color: darkblue"> </td>
        <td><?php echo $count_print; ?> </td>
         <td>
          <?php 
          if ($date_printed == '0000-00-00 00:00:00') 
          {
            echo "NULL";
          }
            else
            {
              echo $date_printed; 
              }
              ?>
        </td>
              
      </tr>
      
              
        
          
<?php 
  }   
  
?>