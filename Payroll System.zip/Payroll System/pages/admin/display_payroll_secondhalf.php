<?php
  require_once("connect.php");
  $user_id = $_SESSION['user_id'];
  $sql="SELECT `payroll_id` as id, `serial_no`, `name`, `position`, `reg_salary`, `amt_earned`, `pera`, `gross_amt`, `abs_w_o_pay`, `life_insurrance`, `pagibig_cont`, `philhealth`, `withholding_tax`, `deped_prov_loan`, `gsis_gfal`, `gsis_help`, `ucpb_loan`, `eastwest_loan`, `chinabank_loan`, `csb_loan`, `bdo_loan`, `pbb_loan`, `lbp_loan`, `first_total_deduc`, `first_net_amt_due`, `sc_gsis_con_loan`, `sc_gsis_eml`, `sc_gsis_policy`, `sc_gsis_help`, `sc_gsis_gfal`, `sc_gsis_mpl`, `sc_gsis_computer`, `sc_pagibig_mpl`, `sc_pagibig_savings`, `sc_csb_loan`, `sc_ucpb_loan`, `sc_chinabank_loan`, `sc_eastwest_loan`, `sc_bdo_loan`, `sc_lbp_loan`, `sc_total_deduction`, `sc_net_amt_due`,`month`,`year`,`count_print`, `date_printed`
   FROM `tbl_payroll`";
  $qry=$DbConnect->prepare($sql);
  $qry->bind_result($id, $serial_no, $name, $position, $reg_salary, $amt_earned, $pera, $gross_amt, $abs_w_o_pay, $life_insurrance, $pagibig_cont, $philhealth, $withholding_tax, $deped_prov_loan, $gsis_gfal, $gsis_help, $ucpb_loan, $eastwest_loan, $chinabank_loan,$csb_loan, $bdo_loan, $pbb_loan, $lbp_loan, $first_total_deduc, $first_net_amt_due, $sc_gsis_con_loan, $sc_gsis_eml, $sc_gsis_policy, $sc_gsis_help,$sc_gsis_gfal, $sc_gsis_mpl, $sc_gsis_computer, $sc_pagibig_mpl, $sc_pagibig_savings, $sc_csb_loan, $sc_ucpb_loan, $sc_chinabank_loan, $sc_eastwest_loan, $sc_bdo_loan, $sc_lbp_loan, $sc_total_deduction, $sc_net_amt_due,$month,$year,$count_print, $date_printed);
  $qry->execute();

  while ($qry->fetch())
  {
    
      ?>

      <tr>
        <td align="center">
        <button style='width:50px; font-size:15px' type='button' class='btn btn-info btn-sm' data-toggle='modal' data-target='#view<?php echo $id; ?>'>  <?php echo $serial_no;?>
            </button>
        </td>
        <td> <?php echo $name;  ?></td>
        <td> <?php echo $position; ?> </td>
        <td> <?php echo number_format($reg_salary,2); ?> </td>
        <td> <?php echo number_format($amt_earned,2); ?> </td>
        <td> <?php echo number_format($pera,2); ?> </td>
        <td> <?php echo number_format($gross_amt,2); ?> </td>
        <td> <?php echo number_format($sc_gsis_con_loan,2); ?> </td>
        <td> <?php echo number_format($sc_gsis_eml,2); ?> </td>
        <td> <?php echo number_format($sc_gsis_policy,2); ?> </td>
        <td> <?php echo number_format($sc_gsis_help,2); ?> </td>
        <td> <?php echo number_format($sc_gsis_gfal,2); ?> </td>
        <td> <?php echo number_format($sc_gsis_mpl,2); ?> </td>
        <td> <?php  echo number_format($sc_gsis_computer,2); ?></td>
        <td> <?php echo number_format($sc_pagibig_mpl,2); ?> </td>
        <td> <?php echo number_format($sc_pagibig_savings,2); ?> </td>
        <td> <?php echo number_format($sc_csb_loan,2); ?> </td>
        <td> <?php echo number_format($sc_ucpb_loan,2); ?> </td>
        <td> <?php echo number_format($sc_chinabank_loan,2); ?> </td>
        <td> <?php echo number_format($sc_eastwest_loan,2); ?> </td>
        <td> <?php echo number_format($sc_bdo_loan,2); ?> </td>
        <td> <?php echo number_format($sc_lbp_loan,2); ?> </td>
        <td> <?php echo number_format($sc_total_deduction,2); ?></td>
        <td> <?php echo number_format($sc_net_amt_due,2); ?></td>
        <td> <?php echo $month.",".$year; ?></td>
      </tr>
      <div class="modal fade" id="view<?php echo $id;?>">
                        <div class="modal-dialog modal-lg">
                      <form action="" method="post" id="form1<?php echo $id; ?>"  name="form1">
                          <div class="modal-content">
                            <div class="modal-header">
                              <h4 class="modal-title">Payroll Summary Report</h4>
                              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                              </button>
                            </div>
                            <div class="card card-primary">
                              <div class="card-body">
                                <div class="col-md-12">
              <div class="card-header p-2">
                <ul class="nav nav-pills">
                  <li class="nav-item"><a class="nav-link active" href="#compensation<?php echo $id; ?>" data-toggle="tab">Compensation</a></li>
                  <li class="nav-item"><a class="nav-link" href="#deduction1<?php echo $id; ?>" data-toggle="tab">1st half deduction</a></li>
                  <li class="nav-item"><a class="nav-link" href="#deduction2<?php echo $id; ?>" data-toggle="tab">2nd half deduction</a></li>
                  <li class="nav-item"><a class="nav-link" href="#total<?php echo $id; ?>" data-toggle="tab">Total</a></li>
                  <li class="nav-item"><a class="nav-link" href="#update<?php echo $id; ?>" data-toggle="tab">Update</a></li>
                </ul>
              </div><!-- /.card-header -->
              <div class="card-body">
                <div class="tab-content">
                  <div class="tab-pane active" id="compensation<?php echo $id; ?>">
                    <form class="form-horizontal">
                      <div class="form-group row">
                        <label for="inputName" class="col-sm-2 col-form-label">Name</label>
                        <div class="col-sm-10">
                          <input type="email" class="form-control" id="inputName" disabled placeholder="<?php echo $name; ?>">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputEmail" class="col-sm-2 col-form-label">Position</label>
                        <div class="col-sm-10">
                          <input type="email" class="form-control" id="inputName" disabled placeholder="<?php echo $position; ?>">
                        </div>
                      </div>
                    </form>
                    <div class="row">
                    <div class="col-4">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Regular Wages</label>
                       <input type="text" class="form-control" disabled id="" value="<?php echo number_format($reg_salary,2); ?>">
                      </div>
                    </div>
                    <div class="col-4">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Amount Earned</label>
                       <input type="text" class="form-control" disabled id="" value="<?php echo number_format($amt_earned,2); ?>">
                      </div>
                    </div>
                    <div class="col-2">
                    <div class="form-group">
                      <label for="exampleInputEmail1">PERA</label>
                       <input type="text" class="form-control" disabled id="" value="<?php echo number_format($pera,2); ?>">
                      </div>
                    </div>
                    <div class="col-2">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Gross</label>
                       <input type="text" class="form-control" disabled id="" value="<?php echo number_format($gross_amt,2); ?>">
                      </div>
                    </div>
                  </div>
                  </div>
                  <!-- /.tab-pane -->
                  <div class="tab-pane" id="deduction1<?php echo $id; ?>">
                    <!-- The timeline -->
                   <form class="form-horizontal">
                      <div class="form-group row">
                        <label for="inputName" class="col-sm-2 col-form-label">Name</label>
                        <div class="col-sm-10">
                          <input type="email" class="form-control" id="inputName" disabled placeholder="<?php echo $name; ?>">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputEmail" class="col-sm-2 col-form-label">Position</label>
                        <div class="col-sm-10">
                          <input type="email" class="form-control" id="inputName" disabled placeholder="<?php echo $position; ?>">
                        </div>
                      </div>
                    </form>
                    <div class="row">
                    <div class="col-3">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Absences</label>
                      <?php 
                       if ($abs_w_o_pay != 0) 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($abs_w_o_pay,2); ?>" style="color: red;" >
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($abs_w_o_pay,2); ?>" >
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                    <div class="col-3">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Life&Ret Insurance</label>
                       <?php 
                       if ($life_insurrance != 0) 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($life_insurrance,2); ?>" style="color: red;" >
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($life_insurrance,2); ?>" >
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                    <div class="col-3">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Pag-ibig Cont</label>
                       <?php 
                       if ($pagibig_cont != 0) 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($pagibig_cont,2); ?>" style="color:red">
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($pagibig_cont,2); ?>" >
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                    <div class="col-3">
                    <div class="form-group">
                      <label for="exampleInputEmail1">PHILHEALTH</label>
                       <?php 
                       if ($philhealth != 0) 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($philhealth,2); ?>" style="color: red;" >
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($philhealth,2); ?>" >
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-3">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Withholding Tax</label>
                      <?php 
                       if ($withholding_tax != 0) 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($withholding_tax,2); ?>" style="color: red;" >
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($withholding_tax,2); ?>" >
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                    <div class="col-3">
                    <div class="form-group">
                      <label for="exampleInputEmail1">DepEd Provident</label>
                       <?php 
                       if ($deped_prov_loan != 0) 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format( $deped_prov_loan,2); ?>"  style="color: red;">
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($deped_prov_loan,2); ?>">
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                    <div class="col-3">
                    <div class="form-group">
                      <label for="exampleInputEmail1">GSIS GFAL</label>
                        <?php 
                       if ($gsis_gfal != 0) 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($gsis_gfal,2); ?>"  style="color: red;">
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($gsis_gfal,2); ?>">
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                    <div class="col-3">
                    <div class="form-group">
                      <label for="exampleInputEmail1">GSIS H.E.L.P</label>
                        <?php 
                       if ($gsis_help != 0) 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($gsis_help,2); ?>"  style="color: red;">
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($gsis_help,2); ?>">
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-3">
                    <div class="form-group">
                      <label for="exampleInputEmail1">UCPB Loan</label>
                       <?php 
                       if ($ucpb_loan != 0) 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($ucpb_loan,2); ?>"  style="color: red;">
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($ucpb_loan,2); ?>">
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                    <div class="col-3">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Eastwest Loan</label>
                        <?php 
                       if ($eastwest_loan != 0) 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($eastwest_loan,2); ?>"  style="color: red;">
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($eastwest_loan,2); ?>">
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                    <div class="col-3">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Chinabank Loan</label>
                        <?php 
                       if ($chinabank_loan != 0) 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($chinabank_loan,2); ?>"  style="color: red;">
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($chinabank_loan,2); ?>">
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                    <div class="col-3">
                    <div class="form-group">
                      <label for="exampleInputEmail1">CSB Loan</label>
                       <?php 
                       if ($deped_prov_loan != 0) 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($deped_prov_loan,2); ?>"  style="color: red;">
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($deped_prov_loan,2); ?>">
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    
                    <div class="col-4">
                    <div class="form-group">
                      <label for="exampleInputEmail1">BDO Loan</label>
                       <?php 
                       if ($bdo_loan != 0) 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($bdo_loan,2); ?>"  style="color: red;">
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($bdo_loan,2); ?>">
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                    <div class="col-4">
                    <div class="form-group">
                      <label for="exampleInputEmail1">PBB Loan</label>
                        <?php 
                       if ($pbb_loan != 0) 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($pbb_loan,2); ?>"  style="color: red;">
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($pbb_loan,2); ?>">
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                    <div class="col-4">
                    <div class="form-group">
                      <label for="exampleInputEmail1">LBP Loan</label>
                        <?php 
                       if ($lbp_loan != 0) 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($lbp_loan,2); ?>"  style="color: red;">
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($lbp_loan,2); ?>">
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                  </div>
                  </div>
                  <div class="tab-pane" id="deduction2<?php echo $id; ?>">
                    <!-- The timeline -->
                   <form class="form-horizontal">
                      <div class="form-group row">
                        <label for="inputName" class="col-sm-2 col-form-label">Name</label>
                        <div class="col-sm-10">
                          <input type="email" class="form-control" id="inputName" disabled placeholder="<?php echo $name; ?>">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputEmail" class="col-sm-2 col-form-label">Position</label>
                        <div class="col-sm-10">
                          <input type="email" class="form-control" id="inputName" disabled placeholder="<?php echo $position; ?>">
                        </div>
                      </div>
                    </form>
                    <div class="row">
                    <div class="col-3">
                    <div class="form-group">
                      <label for="exampleInputEmail1">GSIS Consol Loan</label>
                      <?php 
                       if ($sc_gsis_con_loan != 0) 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_gsis_con_loan,2); ?>" style="color: red;" >
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_gsis_con_loan,2); ?>" >
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                    <div class="col-3">
                    <div class="form-group">
                      <label for="exampleInputEmail1">GSIS EML</label>
                       <?php 
                       if ($sc_gsis_eml != 0 && $sc_gsis_eml !="") 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_gsis_eml,2); ?>" style="color: red;" >
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_gsis_eml,2); ?>" >
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                    <div class="col-3">
                    <div class="form-group">
                      <label for="exampleInputEmail1">GSIS Policy</label>
                       <?php 
                       if ($sc_gsis_policy != 0 && $sc_gsis_policy !="") 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_gsis_policy,2);?>" style="color:red">
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_gsis_policy,2); ?>" >
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                    <div class="col-3">
                    <div class="form-group">
                      <label for="exampleInputEmail1">GSIS H.E.L.P</label>
                       <?php 
                       if ($sc_gsis_help != 0 && $sc_gsis_help !="") 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_gsis_help,2); ?>" style="color: red;" >
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_gsis_help,2); ?>" >
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-3">
                    <div class="form-group">
                      <label for="exampleInputEmail1">GSIS GFAL</label>
                      <?php 
                       if ($sc_gsis_gfal != 0 && $sc_gsis_gfal != "") 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_gsis_gfal,2); ?>" style="color: red;" >
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_gsis_gfal,2); ?>" >
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                    <div class="col-3">
                    <div class="form-group">
                      <label for="exampleInputEmail1">GSIS MPL</label>
                       <?php 
                       if ($sc_gsis_mpl != 0 && $sc_gsis_mpl != "") 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_gsis_mpl,2); ?>"  style="color: red;">
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_gsis_mpl,2); ?>">
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                    <div class="col-3">
                    <div class="form-group">
                      <label for="exampleInputEmail1">GSIS Computer</label>
                        <?php 
                       if ($sc_gsis_computer != 0 && $sc_gsis_computer != "") 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_gsis_computer,2); ?>"  style="color: red;">
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_gsis_computer,2); ?>">
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                    <div class="col-3">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Pag-ibig MPL</label>
                        <?php 
                       if ($sc_pagibig_mpl != 0 && $sc_pagibig_mpl != "") 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_pagibig_mpl,2); ?>"  style="color: red;">
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_pagibig_mpl,2); ?>">
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="col-3">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Pag-ibig MP2</label>
                       <?php 
                       if ($sc_pagibig_savings != 0 && $sc_pagibig_savings != "") 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_pagibig_savings,2); ?>"  style="color: red;">
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_pagibig_savings,2); ?>">
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                    <div class="col-3">
                    <div class="form-group">
                      <label for="exampleInputEmail1">CSB Loan</label>
                        <?php 
                       if ($sc_csb_loan != 0 && $sc_csb_loan != "") 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_csb_loan,2); ?>"  style="color: red;">
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_csb_loan,2); ?>">
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                    <div class="col-3">
                    <div class="form-group">
                      <label for="exampleInputEmail1">UCPB Loan</label>
                        <?php 
                       if ($sc_ucpb_loan != 0 && $sc_ucpb_loan != "") 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_ucpb_loan,2); ?>"  style="color: red;">
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_ucpb_loan,2); ?>">
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                    <div class="col-3">
                    <div class="form-group">
                      <label for="exampleInputEmail1">China bank</label>
                       <?php 
                       if ($sc_chinabank_loan != 0) 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_chinabank_loan,2); ?>"  style="color: red;">
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_chinabank_loan,2); ?>">
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    
                    <div class="col-4">
                    <div class="form-group">
                      <label for="exampleInputEmail1">Eastwest Loan</label>
                       <?php 
                       if ($sc_eastwest_loan != 0 && $sc_eastwest_loan != "") 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_eastwest_loan,2); ?>"  style="color: red;">
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_eastwest_loan,2); ?>">
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                    <div class="col-4">
                    <div class="form-group">
                      <label for="exampleInputEmail1">BDO Loan</label>
                        <?php 
                       if ($sc_bdo_loan != 0 && $sc_bdo_loan != "") 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_bdo_loan,2); ?>"  style="color: red;">
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_bdo_loan,2); ?>">
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                    <div class="col-4">
                    <div class="form-group">
                      <label for="exampleInputEmail1">LBP Loan</label>
                        <?php 
                       if ($sc_lbp_loan != 0 && $sc_lbp_loan != "") 
                       {
                         ?>
                         <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_lbp_loan,2); ?>"  style="color: red;">
                         <?php 
                       }
                         else
                         {
                          ?>
                          <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_lbp_loan,2); ?>">
                         <?php
                       }
                       ?>
                      </div>
                    </div>
                  </div>
                  </div>
                  <!-- /.tab-pane -->

                  <div class="tab-pane" id="total<?php echo $id; ?>">
                    <form class="form-horizontal" action="print_payslip.php"  method="post" id="form5<?php echo $id; ?>" name="form3" target="_blank">
                      <input type="hidden" name="namez" value="<?php echo $name; ?>">
                      <input type="hidden" name="count_printz" value="<?php echo $count_print; ?>">
                      <input type="hidden" name="positionz" class="form-control" value="<?php echo $position; ?>">
                      <input type="hidden" name="idz" value="<?php echo $id; ?>">
                      <input type="hidden"  name="monthz" class="form-control" value="<?php echo $month; ?>">
                      <input type="hidden"  name="yearz" class="form-control" value="<?php echo $year; ?>">
                      <input type="hidden"  name="reg_salaryz" class="form-control" value="<?php echo $reg_salary; ?>">
                      <input type="hidden"  name="amt_earnedz" class="form-control" value="<?php echo $amt_earned; ?>">
                      <input type="hidden"  name="peraz" class="form-control" value="<?php echo $pera; ?>">
                      <input type="hidden"  name="gross_amtz" class="form-control" value="<?php echo $gross_amt; ?>">
                      <input type="hidden"  name="life_insurrancez" class="form-control" value="<?php echo $life_insurrance; ?>">
                      <input type="hidden"  name="abs_w_o_payz" class="form-control" value="<?php echo $abs_w_o_pay; ?>">
                      <input type="hidden"  name="pagibig_contz" class="form-control" value="<?php echo $pagibig_cont; ?>">
                      <input type="hidden"  name="philhealthz" class="form-control" value="<?php echo $philhealth; ?>">
                      <input type="hidden"  name="withholding_taxz" class="form-control" value="<?php echo $withholding_tax; ?>">
                      <input type="hidden" class="form-control" name="deped_prov_loanz" value="<?php echo $deped_prov_loan; ?>">
                      <input type="hidden" class="form-control" name="gsis_gfalz" value="<?php echo $gsis_gfal; ?>">
                      <input type="hidden" class="form-control" name="gsis_helpz" value="<?php echo $gsis_help; ?>">
                      <input type="hidden" class="form-control" name="ucpb_loanz" value="<?php echo $ucpb_loan; ?>">
                      <input type="hidden" class="form-control" name="eastwest_loanz" value="<?php echo $eastwest_loan; ?>">
                      <input type="hidden" class="form-control" name="chinabank_loanz" value="<?php echo $chinabank_loan; ?>">
                      <input type="hidden" class="form-control" name="csb_loanz" value="<?php echo $csb_loan; ?>">
                      <input type="hidden" class="form-control" name="bdo_loanz" value="<?php echo $bdo_loan; ?>">
                      <input type="hidden" class="form-control" name="pbb_loanz" value="<?php echo $pbb_loan; ?>">
                      <input type="hidden" class="form-control" name="lbp_loanz" value="<?php echo $lbp_loan; ?>">
                       <input type="hidden" class="form-control" name="sc_gsis_con_loanz" value="<?php echo $sc_gsis_con_loan; ?>">
                       <input type="hidden" class="form-control" name="sc_gsis_policyz" value="<?php echo $sc_gsis_policy; ?>">
                       <input type="hidden" class="form-control" name="sc_gsis_emlz" value="<?php echo $sc_gsis_eml; ?>">
                       <input type="hidden" class="form-control" name="sc_gsis_helpz" value="<?php echo $sc_gsis_help; ?>">
                       <input type="hidden" class="form-control" name="sc_gsis_gfalz" value="<?php echo $sc_gsis_gfal; ?>">
                       <input type="hidden" class="form-control" name="sc_gsis_mplz" value="<?php echo $sc_gsis_mpl; ?>">
                       <input type="hidden" class="form-control" name="sc_gsis_computerz" value="<?php echo $sc_gsis_computer; ?>">
                       <input type="hidden" class="form-control" name="sc_pagibig_mplz" value="<?php echo $sc_pagibig_mpl; ?>">
                       <input type="hidden" class="form-control" name="sc_pagibig_savingsz" value="<?php echo $sc_pagibig_savings; ?>">
                       <input type="hidden" class="form-control" name="sc_csb_loanz" value="<?php echo $sc_csb_loan; ?>">
                       <input type="hidden" class="form-control" name="sc_ucpb_loanz" value="<?php echo $sc_ucpb_loan; ?>">
                       <input type="hidden" class="form-control" name="sc_chinabank_loanz" value="<?php echo $sc_chinabank_loan; ?>">
                       <input type="hidden" class="form-control" name="sc_eastwest_loanz" value="<?php echo $sc_eastwest_loan; ?>">
                       <input type="hidden" class="form-control" name="sc_bdo_loanz" value="<?php echo $sc_bdo_loan; ?>">
                       <input type="hidden" class="form-control" name="sc_lbp_loanz" value="<?php echo $sc_lbp_loan; ?>">

                      <input type="hidden" class="form-control" name="first_total_deducz" value="<?php echo $first_total_deduc; ?>">
                      <input type="hidden" class="form-control" name="first_net_amt_duez" value="<?php echo $first_net_amt_due; ?>">
                      <input type="hidden" class="form-control" name="sc_net_amt_duez" value="<?php echo $sc_total_deduction; ?>">
                      <input type="hidden" class="form-control" name="sc_net_amt_duez" value="<?php echo $sc_net_amt_due; ?>">
                      <input type="hidden" class="form-control" name="monthz" value="<?php echo $month; ?>">
                      <input type="hidden" class="form-control" name="yearz" value="<?php echo $year; ?>">
                      <div class="form-group row">
                        <label for="inputName" class="col-sm-2 col-form-label">Name</label>
                        <div class="col-sm-10">
                          <input type="email" class="form-control" id="inputName" disabled placeholder="<?php echo $name; ?>">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputEmail" class="col-sm-2 col-form-label">Position</label>
                        <div class="col-sm-10">
                          <input type="email" class="form-control" id="inputName" disabled placeholder="<?php echo $position; ?>">
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-12">
                      <div class="form-group">
                      <label for="exampleInputEmail1">Total Deduction</label>
                       <input type="text" class="form-control" disabled id=""  value="<?php 
                       echo number_format($sc_total_deduction ,2 ); ?>">
                      </div>
                        </div>
                        <div class="col-12">
                      <div class="form-group">
                      <label for="exampleInputEmail1">Net Amount Due</label>
                       <input type="text" class="form-control" disabled id="" value="<?php echo number_format($sc_net_amt_due,2); ?>">
                      </div>
                        </div>
                      </div>
                       <div class="row">
                        <div class="col-4">
                      <div class="form-group">
                      <label for="exampleInputEmail1">Others</label>
                       <input type="text"  class="form-control" name="label" placeholder="Enter Label here.."  required>
                      </div>
                        </div>
                        <div class="col-2">
                      <div class="form-group">
                      <label for="exampleInputEmail1">Amount</label>
                       <input type="number"  class="form-control" name="o_amt" placeholder="0.00" required>
                      </div>
                        </div>
                      </div>

                      <div class="form-group row">
                        <div class="offset-sm-12 col-sm-12">
                         <button type="submit" class="btn bg-gradient-secondary btn-sm" onclick="form5<?php echo $id; ?>.submit();" form="form5"><i class="fa fa-print"></i> Print</button>
                        </div>
                      </div>
                    </form>
                  </div>
                  <div class="tab-pane" id="update<?php echo $id; ?>">
                    <form class="form-horizontal" action="update_payroll2.php"  method="post" id="form4<?php echo $id; ?>" name="form4">
                      <div class="form-group row">
                        <label for="inputName" class="col-sm-2 col-form-label">Name</label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control"  name="name" value="<?php echo $name; ?>">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputEmail" class="col-sm-2 col-form-label">Position</label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" name="position" value="<?php echo $position; ?>">
                        </div>
                      </div>
                      <input type="hidden" name="idz" value="<?php echo $id; ?>">
                      <input type="hidden" name="gross_amt" value="<?php echo $gross_amt; ?>">
                      <div class="row">
                        <div class="col-4">
                      <div class="form-group">
                      <label for="exampleInputEmail1">Regular Wages</label>
                       <input type="number" class="form-control" name="reg_salary" value="<?php echo $reg_salary; ?>">
                      </div>
                        </div>
                        <div class="col-4">
                      <div class="form-group">
                      <label for="exampleInputEmail1">Amount Earned</label>
                       <input type="text"  disabled class="form-control" name="amt_earned" value="<?php echo number_format($amt_earned,2); ?>">
                      </div>
                        </div>
                        <div class="col-2">
                      <div class="form-group">
                      <label for="exampleInputEmail1">PERA</label>
                       <input type="number" class="form-control" name="pera" value="<?php echo $pera; ?>">
                      </div>
                        </div>
                        <div class="col-2">
                      <div class="form-group">
                      <label for="exampleInputEmail1">Gross</label>
                       <input type="text" disabled class="form-control" name="" readonly value="<?php echo number_format($gross_amt,2); ?>">
                      </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-3">
                      <div class="form-group">
                      <label for="exampleInputEmail1">GSIS Consol</label>
                       <input type="number"  class="form-control" name="sc_gsis_con_loan" value="<?php echo $sc_gsis_con_loan; ?>" required>
                      </div>
                        </div>
                        <div class="col-3">
                      <div class="form-group">
                      <label for="exampleInputEmail1">GSIS EML</label>
                       <input type="number"  class="form-control" name="sc_gsis_eml" value="<?php echo $sc_gsis_eml; ?>" required>
                      </div>
                        </div>
                        <div class="col-3">
                      <div class="form-group">
                      <label for="exampleInputEmail1">GSIS Policy</label>
                       <input type="number"  class="form-control" name="sc_gsis_policy" value="<?php echo $sc_gsis_policy; ?>" required>
                      </div>
                        </div>
                        <div class="col-3">
                      <div class="form-group">
                      <label for="exampleInputEmail1">GSIS H.E.L.P</label>
                       <input type="number"  class="form-control" name="sc_gsis_help" value="<?php echo $sc_gsis_help; ?>" required>
                      </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-3">
                      <div class="form-group">
                      <label for="exampleInputEmail1">GSIS GFAL</label>
                       <input type="number"  class="form-control" name="sc_gsis_gfal" value="<?php echo $sc_gsis_gfal; ?>" required>
                      </div>
                        </div>
                        <div class="col-3">
                      <div class="form-group">
                      <label for="exampleInputEmail1">GSIS MPL</label>
                       <input type="number"  class="form-control" name="sc_gsis_mpl" value="<?php echo $sc_gsis_mpl; ?>" required>
                      </div>
                        </div>
                        <div class="col-3">
                      <div class="form-group">
                      <label for="exampleInputEmail1">GSIS Computer</label>
                       <input type="text"  class="form-control" name="sc_gsis_computer" value="<?php echo $sc_gsis_computer; ?>" required>
                      </div>
                        </div>
                        <div class="col-3">
                      <div class="form-group">
                      <label for="exampleInputEmail1">Pag-ibig MPL</label>
                       <input type="number"  class="form-control" name="sc_pagibig_mpl" value="<?php echo $sc_pagibig_mpl; ?>" required>
                      </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-3">
                      <div class="form-group">
                      <label for="exampleInputEmail1">Pag-ibig MP2</label>
                       <input type="number"  class="form-control" name="sc_pagibig_savings" value="<?php echo $sc_pagibig_savings; ?>" required>
                      </div>
                        </div>
                        <div class="col-3">
                      <div class="form-group">
                      <label for="exampleInputEmail1">CSB Loan</label>
                       <input type="number"  class="form-control" name="sc_csb_loan" value="<?php echo $sc_csb_loan; ?>" required>
                      </div>
                        </div>
                        <div class="col-3">
                      <div class="form-group">
                      <label for="exampleInputEmail1">UCPB Loan</label>
                       <input type="number"  class="form-control" name="sc_ucpb_loan" value="<?php echo $sc_ucpb_loan; ?>" required>
                      </div>
                        </div>
                        <div class="col-3">
                      <div class="form-group">
                      <label for="exampleInputEmail1">China Bank</label>
                       <input type="number"  class="form-control" name="sc_chinabank_loan" value="<?php echo $sc_chinabank_loan; ?>" required>
                      </div>
                        </div>
                      </div>
                      <div class="row">
                        <div class="col-4">
                      <div class="form-group">
                      <label for="exampleInputEmail1">Eastwest Loan</label>
                       <input type="number"  class="form-control" name="sc_eastwest_loan" value="<?php echo $sc_eastwest_loan; ?>" required>
                      </div>
                        </div>
                        <div class="col-4">
                      <div class="form-group">
                      <label for="exampleInputEmail1">BDO Loan</label>
                       <input type="number"  class="form-control" name="sc_bdo_loan" value="<?php echo $sc_bdo_loan; ?>" required>
                      </div>
                        </div>
                        <div class="col-4">
                      <div class="form-group">
                      <label for="exampleInputEmail1">LBP Loan</label>
                       <input type="number"  class="form-control" name="sc_lbp_loan" value="<?php echo $sc_lbp_loan; ?>" required>
                      </div>
                        </div>
                      </div>
                     
                      <div class="form-group row">
                        <div class="offset-sm-12 col-sm-12">
                         <button type="submit" class="btn btn-info btn-sm" onclick="form4<?php echo $id; ?>.submit();" form="form4"><i class="fa fa-edit"></i> Update</button>
                        </div>
                      </div>
                    </form>
                  </div>
                  <!-- /.tab-pane -->
                </div>
                <!-- /.tab-content -->
              </div><!-- /.card-body -->
          </div>
                              </div>
                          </div>
                          
                          </div>
                          </form>
                          <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                      </div>
                      <div class="modal fade" id="delete<?php echo $id;?>" style="margin-left: 30%; margin-top: 20%">
         <div class="modal-dialog modal-sm">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title">Are you sure you want delete this data?</h5>
              
            </div>
            
            <div class="modal-footer justify-content-between">
              <button type="button" class="btn btn-danger" data-dismiss="modal"><i class="fa fa-times"></i> No!</button>
              <a href="delete_position.php?$id=<?php echo $id; ?>"><button type="button" class="btn btn-primary"><i class="fa fa-check"></i> Yes!</button></a>
            </div>
          </div>
          <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
      </div>
         


          
<?php 
  }   
  
?>