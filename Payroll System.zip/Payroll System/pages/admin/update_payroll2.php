
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="sweetalert.css">
        <script type="text/javascript" src="sweetalert-dev.js"></script>
    </head>
    

    <body>
        
    </body>

</html>
<?php
require_once 'connect.php';

$payroll_id= isset($_POST['idz'])? $_POST['idz']:"";
 $position=$_POST['position'];
$name=$_POST['name'];
$reg_salary=$_POST['reg_salary'];
$pera=$_POST['pera'];
$amt_earned = $reg_salary / 2;
$gross_amt = $amt_earned+$pera;
$sc_gsis_con_loan=$_POST['sc_gsis_con_loan'];
$sc_gsis_eml=$_POST['sc_gsis_eml'];
$sc_gsis_policy=$_POST['sc_gsis_policy'];
$sc_gsis_help=$_POST['sc_gsis_help'];
$sc_gsis_gfal=$_POST['sc_gsis_gfal'];
$sc_gsis_mpl=$_POST['sc_gsis_mpl'];
$sc_gsis_computer=$_POST['sc_gsis_computer'];
$sc_pagibig_mpl=$_POST['sc_pagibig_mpl'];
$sc_pagibig_savings=$_POST['sc_pagibig_savings'];
$sc_csb_loan=$_POST['sc_csb_loan'];
$sc_ucpb_loan=$_POST['sc_ucpb_loan'];
$sc_chinabank_loan=$_POST['sc_chinabank_loan'];
$sc_eastwest_loan=$_POST['sc_eastwest_loan'];
$sc_bdo_loan=$_POST['sc_bdo_loan'];
$sc_lbp_loan=$_POST['sc_lbp_loan'];
if ($name!="" && $position!="" && $reg_salary!=="" && $pera!=="" && $sc_gsis_con_loan!=="" && $sc_gsis_con_loan!=="" && $sc_gsis_policy!=="" &&  $sc_gsis_eml!=="" && $sc_gsis_help!=="" &&  $sc_gsis_gfal!=="" && $sc_gsis_mpl!=="" &&  $sc_gsis_computer!=="" &&  $sc_pagibig_mpl!=="" &&  $sc_pagibig_savings!=="" &&  $sc_csb_loan!=="" &&  $sc_ucpb_loan!=="" &&  $sc_chinabank_loan!=="" &&  $sc_eastwest_loan!=="" &&  $sc_bdo_loan!=="" &&  $sc_lbp_loan!=="")
{
$sc_total_deduction =$sc_gsis_con_loan+$sc_gsis_policy+$sc_gsis_eml+$sc_gsis_help+$sc_gsis_gfal+$sc_gsis_mpl+$sc_gsis_computer+$sc_pagibig_mpl+$sc_pagibig_savings+$sc_csb_loan+$sc_ucpb_loan+$sc_chinabank_loan+$sc_eastwest_loan+$sc_bdo_loan+$sc_lbp_loan;
$sc_net_amt_due = $gross_amt-$sc_total_deduction;

    $sql = "UPDATE tbl_payroll SET name=?, position=?,reg_salary=?, amt_earned=?, pera=?, gross_amt=?, sc_gsis_con_loan=?,sc_gsis_eml=?,sc_gsis_policy=?,sc_gsis_help=?,sc_gsis_gfal=?,sc_gsis_mpl=?,sc_gsis_computer=?,sc_pagibig_mpl=?,sc_pagibig_savings=?,sc_csb_loan=?,sc_ucpb_loan=?,sc_chinabank_loan=?,sc_eastwest_loan=?,sc_bdo_loan=?,sc_lbp_loan=?,sc_total_deduction=?,sc_net_amt_due=? WHERE payroll_id=?";
    $qry =$DbConnect->prepare($sql);
    $qry->bind_param("ssssssssssssssssssssssss",$name,$position,$reg_salary,$amt_earned,$pera,$gross_amt,$sc_gsis_con_loan,$sc_gsis_eml, $sc_gsis_policy,$sc_gsis_help,$sc_gsis_gfal,$sc_gsis_mpl,$sc_gsis_computer,$sc_pagibig_mpl,$sc_pagibig_savings,$sc_csb_loan,$sc_ucpb_loan,$sc_chinabank_loan,$sc_eastwest_loan,$sc_bdo_loan,$sc_lbp_loan,$sc_total_deduction,$sc_net_amt_due,$payroll_id);
    if ($qry->execute())
    {
        succ();
    }
    else
    {
    err();
    }
}
else
{
    err2();
}
function succ()
        {
            echo '<script>
            swal({
                title: "Updated Successfully",
                type: "success",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "payroll2.php ";
            });
            </script>';
        }
        function err()
        {
            echo '<script>
            swal({
                title: "Error!!...",
                type: "error",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "payroll2.php ";
            });
            </script>';
        }
          function err2()
        {
            echo '<script>
            swal({
                title: "Error!!..missing require fields",
                type: "warning",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "payroll2.php ";
            });
            </script>';
        }
        ?>