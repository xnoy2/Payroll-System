 <?php
include 'connect.php';
session_start();

if ($_SESSION['user_id'] ==!empty($user_id))
{
  
  header ('location:../index.php');
}
?>
  <?php
  require_once("connect.php");
  

  $user_id = $_SESSION['user_id'];
  $user_type = $_SESSION['user_type'];
  if ($user_type != "Admin")
  {
     header ('location:logoutsession.php');
  }
  else
  {
  $sql= "SELECT user_id,username,password,fullname,user_type FROM tbl_user WHERE user_id=? AND user_type='Admin' ";
              
  $qry=$DbConnect->prepare($sql);
  $qry->bind_result($user_id,$username,$password,$fullname,$user_type);
  $qry->bind_param("s",$user_id);
  $qry->execute();

  while ($qry->fetch())
  { 
    ?>
  
<?php
}
}
  ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>SNHS Payroll System</title>

  <!-- Google Font: Source Sans Pro -->
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="../../plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <link rel="stylesheet" href="../../plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- Daterange picker -->
  <!-- summernote -->
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

  <!-- Preloader -->
  <div class="preloader flex-column justify-content-center align-items-center">
    <img class="animation__shake" src="../../dist/img/3.gif" alt="AdminLTELogo" height="60" width="60">
  </div>

  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Navbar Search -->
      <li class="nav-item">
        <a class="nav-link" data-widget="fullscreen" href="#" role="button">
          <i class="fas fa-expand-arrows-alt"></i>
        </a>
      </li>
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="" class="brand-link">
      <img src="../../dist/img/snhs.png" alt="" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-light">SNHS Payroll System</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="../../dist/img/user.png" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block"><?php echo $fullname; ?></a>
        </div>
      </div>

 

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item menu-open">
            <a href="dashboard.php" class="nav-link active">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="payroll.php" class="nav-link">
              <i class="nav-icon fas fa-money-bill-wave"></i>
              <p>
                Payroll
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="department.php" class="nav-link">
              <i class="nav-icon fas fa-building"></i>
              <p>
                Department
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="employee.php" class="nav-link">
              <i class="nav-icon fas fa-users"></i>
              <p>
                Employee
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="position.php" class="nav-link">
              <i class="nav-icon fas fa-user-tag"></i>
              <p>
                Position
              </p>
            </a>
          </li>
          
          <li class="nav-item">
            <a href="backup.php" class="nav-link">
              <i class="nav-icon fas fa-database"></i>
              <p>
                Backup Database
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="logoutsession.php" class="nav-link">
              <i class="nav-icon fas fa-power-off"></i>
              <p>
                Logout
              </p>
            </a>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>
    <!-- /.content-header -->

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <!-- Small boxes (Stat box) -->
        <div class="row">
                  <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3><?php $mysqli = new mysqli("localhost", "root", "", "payrollsystemdb");

// prepare your SQL statement using a parameterized query
$stmt = $mysqli->prepare("SELECT COUNT(*) FROM tbl_payroll");

// execute the statement
$stmt->execute();

// bind the result to a variable
$stmt->bind_result($count);

// fetch the result
$stmt->fetch();

// output the result
echo $count;

// close the statement and database connection
$stmt->close();
$mysqli->close(); ?></h3>

                <p>Total Payroll Item</p>
              </div>
              <div class="icon">
                <i class="fa fa-list"></i>
              </div>
              <a href="payroll.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h3><?php $mysqli = new mysqli("localhost", "root", "", "payrollsystemdb");

// prepare your SQL statement using a parameterized query
$stmt = $mysqli->prepare("SELECT COUNT(*) FROM tbl_department");

// execute the statement
$stmt->execute();

// bind the result to a variable
$stmt->bind_result($count);

// fetch the result
$stmt->fetch();

// output the result
echo $count;

// close the statement and database connection
$stmt->close();
$mysqli->close(); ?></h3>

                <p>Total Departments</p>
              </div>
              <div class="icon">
                <i class="fa fa-building"></i>
              </div>
              <a href="department.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-primary">
              <div class="inner">
                <h3><?php $mysqli = new mysqli("localhost", "root", "", "payrollsystemdb");

// prepare your SQL statement using a parameterized query
$stmt = $mysqli->prepare("SELECT COUNT(*) FROM tbl_position");

// execute the statement
$stmt->execute();

// bind the result to a variable
$stmt->bind_result($count);

// fetch the result
$stmt->fetch();

// output the result
echo $count;

// close the statement and database connection
$stmt->close();
$mysqli->close(); ?></h3>

                <p>Total Position</p>
              </div>
              <div class="icon">
                <i class="fa fa-user-tag"></i>
              </div>
              <a href="position.php" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-danger">
              <div class="inner">
                <h3><?php $mysqli = new mysqli("localhost", "root", "", "payrollsystemdb");

// prepare your SQL statement using a parameterized query
$stmt = $mysqli->prepare("SELECT COUNT(*) FROM tbl_user");

// execute the statement
$stmt->execute();

// bind the result to a variable
$stmt->bind_result($count);

// fetch the result
$stmt->fetch();

// output the result
echo $count;

// close the statement and database connection
$stmt->close();
$mysqli->close(); ?></h3>

                <p>Total Users</p>
              </div>
              <div class="icon">
                <i class="fa fa-users"></i>
              </div>
              <a href="#" class="small-box-footer">More info <i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
        </div>
        <!-- /.row -->
        <!-- Main row -->
      
        <div class="row">
          <div class="col-6">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Deduction Table</h3>

                <div class="card-tools">
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: 300px;">
                <table class="table table-head-fixed text-nowrap">
                  <thead>
                    <tr>
                      <th>Deduction #</th>
                      <th>Deduction</th>
                      <th>Amount</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php 
                    require_once"connect.php";
                    $sql="SELECT `payroll_id`, sum(`abs_w_o_pay`) as total_abs_w_o_pay, sum(`life_insurrance`) as total_life_insurrance, sum(`pagibig_cont`) as total_pagibig_cont, sum(`philhealth`) as total_philhealth, sum(`withholding_tax`) as total_withholding_tax, sum(`deped_prov_loan`) as total_deped_prov_loan, sum(`gsis_gfal`)+ sum(`sc_gsis_gfal`) as total_gsis_gfal, sum(`gsis_help`)+sum(`sc_gsis_help`) as total_gsis_help, sum(`ucpb_loan`)+sum(`sc_ucpb_loan`) as total_ucpb_loan, sum(`eastwest_loan`)+sum(`sc_eastwest_loan`) as total_eastwest_loan, sum(`chinabank_loan`)+sum(`sc_chinabank_loan`) as total_chinabank_loan, sum(`csb_loan`)+sum(`sc_csb_loan`) as total_csb_loan, sum(`bdo_loan`)+sum(`sc_bdo_loan`) as total_bdo_loan, sum(`pbb_loan`) as total_pbb_loan, sum(`lbp_loan`)+sum(`sc_lbp_loan`) as total_lbp_loan, sum(`sc_gsis_con_loan`) as total_sc_gsis_con_loan, sum(`sc_gsis_eml`) as total_sc_gsis_eml, sum(`sc_gsis_policy`) as total_sc_gsis_policy, sum(`sc_gsis_mpl`) as total_sc_gsis_mpl, sum(`sc_gsis_computer`) as total_sc_gsis_computer, sum(`sc_pagibig_mpl`) as total_sc_pagibig_mpl, sum(`sc_pagibig_savings`) as total_sc_pagibigi_savings FROM `tbl_payroll`";
                        $qry=$DbConnect->prepare($sql);
                        $qry->bind_result($payroll_id,$total_abs_w_o_pay,$total_life_insurrance,$total_pagibig_cont,$total_philhealth,$total_withholding_tax,$total_deped_prov_loan,$total_gsis_gfal,$total_gsis_help,$total_ucpb_loan,$total_eastwest_loan,$total_chinabank_loan,$total_csb_loan,$total_bdo_loan,$total_pbb_loan,$total_lbp_loan,$total_sc_gsis_con_loan,$total_sc_gsis_eml,$total_sc_gsis_policy,$total_sc_gsis_mpl,$total_sc_gsis_computer,$total_sc_pagibig_mpl,$total_sc_pagibigi_savings);

                        $qry->execute();
                       while ($qry->fetch()) 
                       {
                        ?>
                      
                       <?php
                     }
                    ?>
                   <tr>
                      <td></td>
                      <td>Absences w/o Pay</td>
                      <td><?php echo number_format($total_abs_w_o_pay,2); ?></td>
                    </tr>
                     <tr>
                      <td></td>
                      <td>Life & Ret Insurance</td>
                      <td><?php echo number_format($total_life_insurrance,2); ?></td>
                    </tr>
                     <tr>
                      <td></td>
                      <td>Pagibig Cont</td>
                      <td><?php echo number_format($total_pagibig_cont,2); ?></td>
                    </tr>
                     <tr>
                      <td></td>
                      <td>Philhealth</td>
                      <td><?php echo number_format($total_philhealth,2); ?></td>
                    </tr>
                     <tr>
                      <td></td>
                      <td>Witholding Tax</td>
                      <td><?php echo number_format($total_withholding_tax,2); ?></td>
                    </tr>
                     <tr>
                      <td></td>
                      <td>Deped Provident</td>
                      <td><?php echo number_format($total_deped_prov_loan,2); ?></td>
                    </tr>
                     <tr>
                      <td>202102012</td>
                      <td>GSIS GFAL</td>
                      <td><?php echo number_format($total_gsis_gfal,2); ?></td>
                    </tr>
                     <tr>
                      <td>2020102000</td>
                      <td>GSIS H.E.L.P</td>
                      <td><?php echo number_format($total_gsis_help,2); ?></td>
                    </tr>
                     <tr>
                      <td>2999999000</td>
                      <td>UCPB</td>
                      <td><?php echo number_format($total_ucpb_loan,2); ?></td>
                    </tr>
                     <tr>
                      <td>2999999000</td>
                      <td>Eastwest</td>
                      <td><?php echo number_format($total_eastwest_loan,2); ?></td>
                    </tr>
                     <tr>
                      <td>2999999000</td>
                      <td>China Bank</td>
                      <td><?php echo number_format($total_chinabank_loan,2); ?></td>
                    </tr>
                     <tr>
                      <td>2999999000</td>
                      <td>CSB</td>
                      <td><?php echo number_format($total_csb_loan,2); ?></td>
                    </tr>
                     <tr>
                      <td>2999999000</td>
                      <td>BDO</td>
                      <td><?php echo number_format($total_bdo_loan,2); ?></td>
                    </tr>
                    <tr>
                      <td></td>
                      <td>PBB</td>
                      <td><?php echo number_format($total_pbb_loan,2); ?></td>
                    </tr>
                    <tr>
                      <td>2999999000</td>
                      <td>LBP</td>
                      <td><?php echo number_format($total_lbp_loan,2); ?></td>
                    </tr>
                    <tr>
                      <td>2020102003</td>
                      <td>GSIS Consol</td>
                      <td><?php echo number_format($total_sc_gsis_con_loan,2); ?></td>
                    </tr>
                    <tr>
                      <td>2020102000</td>
                      <td>GSIS EML</td>
                      <td><?php echo number_format($total_sc_gsis_eml,2); ?></td>
                    </tr>
                    <tr>
                      <td>2020102004</td>
                      <td>GSIS POLICY</td>
                      <td><?php echo number_format($total_sc_gsis_policy,2); ?></td>
                    </tr>
                    <tr>
                      <td></td>
                      <td>GSIS MPL</td>
                      <td><?php echo number_format($total_sc_gsis_mpl,2); ?></td>
                    </tr>
                    <tr>
                      <td>12345678</td>
                      <td>GSIS Computer</td>
                      <td><?php echo number_format($total_sc_gsis_computer,2); ?></td>
                    </tr>
                    <tr>
                      <td>2020103002</td>
                      <td>Pagibig MPL</td>
                      <td><?php echo number_format($total_sc_pagibig_mpl,2); ?></td>
                    </tr>
                    <tr>
                      <td></td>
                      <td>Pagibig MP2 Savings</td>
                      <td><?php echo number_format($total_sc_pagibigi_savings,2); ?></td>
                    </tr>

                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <div class="col-6">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Logs Table</h3>

                <div class="card-tools">
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0" style="height: 300px;">
                <table id="example1" class="table table-bordered table-striped">
                  <thead>
                  <tr>
                    <th>Name</th>
                    <th>No. of Print</th>
                    <th>Date & Time</th>
                  
                  </tr>
                  </thead>
                  <tbody>
                    <?php include 'display_logs.php'; ?>
                  </tbody>
                  <tfoot>
                  <tr>
                    <th>Name</th>
                    <th>No. of Print</th>
                    <th>Date & Time</th>
                    
                  </tr>
                  </tfoot>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div>
        <!-- /.row (main row) -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <strong>Sagay National High School Payroll System <a href="">2023</a>.</strong>
    <div class="float-right d-none d-sm-inline-block">
      <b>Footer</b>
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->

<!-- AdminLTE for demo purposes -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->

<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- FLOT CHARTS -->
<script src="../../plugins/flot/jquery.flot.js"></script>
<!-- FLOT RESIZE PLUGIN - allows the chart to redraw when the window is resized -->
<script src="../../plugins/flot/plugins/jquery.flot.resize.js"></script>
<!-- FLOT PIE PLUGIN - also used to draw donut charts -->
<script src="../../plugins/flot/plugins/jquery.flot.pie.js"></script>

<script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
<script src="../../plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="../../plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="../../plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="../../plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="../../plugins/pdfmake/vfs_fonts.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<!-- AdminLTE App -->
<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true, "lengthChange": false, "autoWidth": false,
      "buttons": ["copy", "excel", "print", ""]
    }).buttons().container().appendTo('#example1_wrapper .col-md-6:eq(0)');
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>


</body>
</html>
