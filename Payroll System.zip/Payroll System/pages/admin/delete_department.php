<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="sweetalert.css">
		<script type="text/javascript" src="sweetalert-dev.js"></script>
	</head>
	

	<body>
		
	</body>

</html>
<?php

require_once 'connect.php';

$dept_id =$_GET['dept_id'];
$sql="DELETE FROM tbl_department WHERE dept_id=?";
$qry=$DbConnect->prepare($sql);
$qry->bind_param("s",$dept_id);
if($qry->execute()==true)
{
	succ();
	
} 
else
{
	err();

}

function succ()
		{
			echo '<script>
			swal({
				title: "Deleted Successfuly",
				type: "success",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "department.php ";
			});
			</script>';
		}
		function err()
		{
			echo '<script>
			swal({
				title: "ERROR!!",
				type: "error",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "department.php ";
			});
			</script>';
		}

		?>