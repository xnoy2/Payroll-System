<?php
include 'connect.php';

date_default_timezone_set('Asia/Manila');
 $payroll_id= isset($_POST['idz'])? $_POST['idz']:"";
 $count= isset($_POST['count_printz'])? $_POST['count_printz']:"";
 $cov = intval($count);
$count_print = $cov + 1;
$count_print;
$todays_date = date("y-m-d h:i:s");
$date_p = strtotime($todays_date);
$date_printed = date("y-m-d h:i:s", $date_p);


$sql = "UPDATE tbl_payroll SET count_print=?, date_printed=? WHERE payroll_id=?";
$qry = $DbConnect->prepare($sql);
$qry->bind_param("iss", $count_print, $date_printed, $payroll_id);
if ($qry->execute())
{

?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" type="text/css" href="bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="bundle.min.js">
  <link rel="stylesheet" type="text/css" href="jquery.min.js">
 <title>Payslip</title>
</head>
<body>
<div class="container mt-5 mb-5">
    <div class="row">
        <div class="col-md-12">
            <div class="text-center lh-1 mb-2">
                <h6 class="fw-bold" style="font-family: Old English Text MT;"><img src="../../dist/img/snhs.png" alt="" class="brand-image img-circle elevation-3" style="opacity: .8; width:70px"><br>Republic of the philippines</h6><h5 class="fw-bold" style="font-family: Old English Text MT; margin-top:-8px; font-size: 30px;">Department of Education</h5><h4 class="" style="font-family: Graphik; margin-top:4px; font-size: 18px;">REGION VI - Western Visayas</h4><br>
                <h4 class="fw-bold" style="font-family: Graphik; margin-top:-20px; font-size:17px;">SCHOOL DIVISION OF SAGAY CITY</h4><br>
                <h4 class="fw-bold" style="font-family: Graphik; margin-top:-20px; margin-bottom: -10px; font-size:18px;">SAGAY NATIONAL HIGH SCHOOL</h4><b style="margin-top:-10px">________________________________________________________________________</b>

            </div>
            <div class="row">
                <div class="col-md-10">
                    <div class="row">
                        <div class="col-md-6">
                            <div> <span class="fw-bolder">EMPLOYEE'S NAME:</span> <small class="ms-3"><b style="font-size: 16px;"><u>
                                <?php
                                require_once 'connect.php';
                                $label = $_POST['label'];
                                $o_amt = $_POST['o_amt'];
                                $name= isset($_POST['namez'])? $_POST['namez']:"";
                                $position= isset($_POST['positionz'])? $_POST['positionz']:"";
                                $reg_salary= isset($_POST['reg_salaryz'])? $_POST['reg_salaryz']:"";
                                $amt_earned= isset($_POST['amt_earnedz'])? $_POST['amt_earnedz']:"";
                                $pera= isset($_POST['peraz'])? $_POST['peraz']:"";
                                $gross_amt= isset($_POST['gross_amtz'])? $_POST['gross_amtz']:"";
                                $abs_w_o_pay= isset($_POST['abs_w_o_payz'])? $_POST['abs_w_o_payz']:"";
                                $life_insurrance= isset($_POST['life_insurrancez'])? $_POST['life_insurrancez']:"";
                                $pagibig_cont= isset($_POST['pagibig_contz'])? $_POST['pagibig_contz']:"";
                                $philhealth= isset($_POST['philhealthz'])? $_POST['philhealthz']:"";
                                $withholding_tax= isset($_POST['withholding_taxz'])? $_POST['withholding_taxz']:"";
                                $gsis_gfal= isset($_POST['gsis_gfalz'])? $_POST['gsis_gfalz']:"";
                                $gsis_help= isset($_POST['gsis_helpz'])? $_POST['gsis_helpz']:"";
                                $ucpb_loan= isset($_POST['ucpb_loanz'])? $_POST['ucpb_loanz']:"";
                                $eastwest_loan= isset($_POST['eastwest_loanz'])? $_POST['eastwest_loanz']:"";
                                $chinabank_loan= isset($_POST['chinabank_loanz'])? $_POST['chinabank_loanz']:"";
                                $csb_loan= isset($_POST['csb_loanz'])? $_POST['csb_loanz']:"";
                                $bdo_loan= isset($_POST['bdo_loanz'])? $_POST['bdo_loanz']:"";
                                $pbb_loan= isset($_POST['pbb_loanz'])? $_POST['pbb_loanz']:"";
                                $lbp_loan= isset($_POST['lbp_loanz'])? $_POST['lbp_loanz']:"";
                                $first_total_deduc= isset($_POST['first_total_deducz'])? $_POST['first_total_deducz']:"";
                                $first_net_amt_due= isset($_POST['first_net_amt_duez'])? $_POST['first_net_amt_duez']:"";
                                $sc_gsis_con_loan=isset($_POST['sc_gsis_con_loanz'])? $_POST['sc_gsis_con_loanz']:"";
                                $sc_gsis_policy=isset($_POST['sc_gsis_policyz'])? $_POST['sc_gsis_policyz']:"";
                                $sc_gsis_eml=isset($_POST['sc_gsis_emlz'])? $_POST['sc_gsis_emlz']:"";
                                $sc_gsis_help=isset($_POST['sc_gsis_helpz'])? $_POST['sc_gsis_helpz']:"";
                                $sc_gsis_gfal=isset($_POST['sc_gsis_gfalz'])? $_POST['sc_gsis_gfalz']:"";
                                $sc_gsis_mpl=isset($_POST['sc_gsis_mplz'])? $_POST['sc_gsis_mplz']:"";
                                $sc_gsis_computer=isset($_POST['sc_gsis_computerz'])? $_POST['sc_gsis_computerz']:"";
                                $sc_pagibig_mpl=isset($_POST['sc_pagibig_mplz'])? $_POST['sc_pagibig_mplz']:"";
                                $sc_pagibig_savings=isset($_POST['sc_pagibig_savingsz'])? $_POST['sc_pagibig_savingsz']:"";
                                $sc_csb_loan=isset($_POST['sc_csb_loanz'])? $_POST['sc_csb_loanz']:"";
                                $sc_ucpb_loan=isset($_POST['sc_ucpb_loanz'])? $_POST['sc_ucpb_loanz']:"";
                                $sc_chinabank_loan=isset($_POST['sc_chinabank_loanz'])? $_POST['sc_chinabank_loanz']:"";
                                $sc_eastwest_loan=isset($_POST['sc_eastwest_loanz'])? $_POST['sc_eastwest_loanz']:"";
                                 $deped_prov_loan= isset($_POST['deped_prov_loanz'])? $_POST['deped_prov_loanz']:"";
                                $sc_bdo_loan=isset($_POST['sc_bdo_loanz'])? $_POST['sc_bdo_loanz']:"";
                                $sc_lbp_loan=isset($_POST['sc_lbp_loanz'])? $_POST['sc_lbp_loanz']:"";
                                $sc_net_amt_due= isset($_POST['sc_net_amt_duez'])? $_POST['sc_net_amt_duez']:"";
                                $month= isset($_POST['monthz'])? $_POST['monthz']:"";
                                $year= isset($_POST['yearz'])? $_POST['yearz']:"";
                                echo $name; ?></u></b></small> </div>
                        </div>
                        <div class="col-md-6">
                            <div> <span class="fw-bolder">POSITION:</span> <small class="ms-3"><b style="font-size: 16px;"><u><?php echo $position; ?></u></b></small> </div>
                        </div>
                        <div class="col-md-6">
                            <div> <span class="fw-bolder">FOR THE MONTH OF:</span> <small class="ms-3"><b style="font-size: 16px;"><u><?php echo $month.",".$year; ?> </u></b></small> </div>
                        </div>
                    </div>
                </div>
                <table class="mt-4 table table-bordered">
                    <thead class="bg-dark text-white">
                        <tr>
                            <th scope="col">Earnings</th>
                            <th scope="col">Amount</th>
                            <th scope="col">Deductions</th>
                            <th scope="col">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                         <tr>
                            <th scope="row">Basic</th>
                            <td><?php
                             
                                  echo number_format($reg_salary,2);
                            ?></td>
                            <td>Life&Ret. Insurance</td>
                            <td><?php
                             
                                  echo number_format($life_insurrance,2);
                            ?></td>
                        </tr>
                        
                        <tr>
                            <th scope="row">Add:ACA</th>
                            <td><?php $pera1=$pera*2;
                            echo number_format($pera1,2);
                            ?></td>
                            <td>Pag-Ibig Contribution</td>
                            <td><?php
                             
                                  echo number_format($pagibig_cont,2);
                            ?></td>
                        </tr>
                        
                        <tr>
                            <td></td>
                            <td></td>
                            <td>PhilHealth</td>
                            <td><?php
                             
                                  echo number_format($philhealth,2);
                            ?></td>
                        </tr>
                        <?php 
                        if ($withholding_tax != 0 && $withholding_tax != "") 
                        {
                         ?>
                         <tr>
                            <td></td>
                            <td></td>
                            <td>Withholding Tax</td>
                            <td><?php
                             
                                  echo number_format($withholding_tax,2);
                            ?></td>
                        </tr>
                        <?php
                    }
                    else
                    {
                        ?>
                        
                    <?php
                }
                    ?>
                        <?php 
                        if ($deped_prov_loan != 0 && $deped_prov_loan != "") 
                        {
                         ?>
                         <tr>
                            <td></td>
                            <td></td>
                            <td>DepEd Provident Loan</td>
                            <td><?php
                             
                                  echo number_format($deped_prov_loan,2);
                            ?></td>
                        </tr>
                        <?php
                    }
                    else
                    {
                        ?>
                        
                    <?php
                }
                    ?>
                        <?php 
                        if ($gsis_gfal != 0 && $gsis_gfal !="") 
                        {
                         ?>
                         <tr>
                            <td></td>
                            <td></td>
                            <td>GSIS GFAL</td>
                            <td><?php
                                    $total_gfal = $gsis_gfal+$sc_gsis_gfal;
                                  echo number_format($total_gfal,2);
                            ?></td>
                        </tr>
                        <?php
                    }
                    else if ($sc_gsis_gfal!= 0 && $sc_gsis_gfal!= "") {?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td>GSIS GFAL</td>
                            <td><?php
                                    $total_gfal = $gsis_gfal+$sc_gsis_gfal;
                                  echo number_format($total_gfal,2);
                            ?></td>
                        </tr>
                    <?php
                }
                    else
                    {
                        ?>
                    <?php
                }
                    ?>
                        <?php 
                        if ($gsis_help != 0 && $gsis_help !="" ) 
                        {
                         ?>
                         <tr>
                            <td></td>
                            <td></td>
                            <td>GSIS H.E.L.P</td>
                            <td><?php
                            $gsis_help_total = $gsis_help+$sc_gsis_help;
                                  echo number_format($gsis_help_total,2);
                            ?></td>
                        </tr>
                        <?php
                    }
                    else if ($sc_gsis_help!= 0 && $sc_gsis_help!= "") {
                        ?>
                        <tr>
                            <td></td>
                            <td></td>
                            <td>GSIS H.E.L.P</td>
                            <td><?php
                                    $total_help = $gsis_help+$sc_gsis_help;
                                  echo number_format($total_help,2);
                            ?></td>
                        </tr>
                    <?php
                }
                    else
                    {
                        ?>
                        
                    <?php
                }
                    ?>
                        <?php 
                        if ($ucpb_loan != 0 && $ucpb_loan != "") 
                        {
                         ?>
                         <tr>
                            <td></td>
                            <td></td>
                            <td>UCPB Loan</td>
                            <td><?php
                             
                                  $total_ucpb = $ucpb_loan+$sc_ucpb_loan;
                                  echo number_format($total_ucpb,2);
                            ?></td>
                        </tr>
                        <?php
                    }
                    else if ($sc_ucpb_loan != 0 && $sc_ucpb_loan != "") 
                        {
                         ?>
                         <tr>
                            <td></td>
                            <td></td>
                            <td>UCPB Loan</td>
                            <td><?php
                                  $total_ucpb = $ucpb_loan+$sc_ucpb_loan;
                                  echo number_format($total_ucpb,2);
                            ?></td>
                        </tr>
                        <?php
                    }
                    else
                    {
                        ?>
                        
                    <?php
                }
                    ?>
                    <?php 
                        if ($eastwest_loan != 0 && $eastwest_loan != "") 
                        {
                         ?>
                         <tr>
                            <td></td>
                            <td></td>
                            <td>Eastwest Loan</td>
                            <td><?php
                                    $total_eastwest = $eastwest_loan+$sc_eastwest_loan;
                                  echo number_format($total_eastwest,2);
                                  
                            ?></td>
                        </tr>
                        <?php
                    }
                    else if ($sc_eastwest_loan != 0 && $sc_eastwest_loan != "") 
                        {
                         ?>
                         <tr>
                            <td></td>
                            <td></td>
                            <td>Eastwest Loan</td>
                            <td><?php
                                    $total_eastwest = $eastwest_loan+$sc_eastwest_loan;
                                  echo number_format($total_eastwest,2);
                                  
                            ?></td>
                        </tr>
                        <?php
                    }
                    else
                    {
                        ?>
                        
                    <?php
                }
                    ?>
                    <?php 
                        if ($chinabank_loan != 0 && $chinabank_loan != "") 
                        {
                         ?>
                         <tr>
                            <td></td>
                            <td></td>
                            <td>China Bank Loan</td>
                            <td><?php
                             
                                  $total_chinabank = $chinabank_loan+$sc_chinabank_loan;
                                  echo number_format($total_chinabank,2);
                            ?></td>
                        </tr>
                        <?php
                    }
                    else if ($sc_chinabank_loan != 0 && $sc_chinabank_loan != "") 
                        {
                         ?>
                         <tr>
                            <td></td>
                            <td></td>
                            <td>China Bank Loan</td>
                            <td><?php
                             
                                  $total_chinabank = $chinabank_loan+$sc_chinabank_loan;
                                  echo number_format($total_chinabank,2);
                            ?></td>
                        </tr>
                        <?php
                    }
                    else
                    {
                        ?>
                        
                    <?php
                }
                    ?>
                    <?php 
                        if ($csb_loan != 0 && $csb_loan != "") 
                        {
                         ?>
                         <tr>
                            <td></td>
                            <td></td>
                            <td>CSB Loan</td>
                            <td><?php
                            $total_csb = $csb_loan+$sc_csb_loan;
                                  echo number_format($total_csb,2);
                            ?></td>
                        </tr>
                        <?php
                    }
                     else if ($sc_csb_loan != 0 && $sc_csb_loan != "") 
                        {
                         ?>
                         <tr>
                            <td></td>
                            <td></td>
                            <td>CSB Loan</td>
                            <td><?php
                            $total_csb = $csb_loan+$sc_csb_loan;
                                  echo number_format($total_csb,2);
                            ?></td>
                        </tr>
                        <?php
                    }
                    else
                    {
                        ?>
                        
                    <?php
                }
                    ?>
                    <?php 
                        if ($bdo_loan != 0 && $bdo_loan != "") 
                        {
                         ?>
                         <tr>
                            <td></td>
                            <td></td>
                            <td>BDO Loan</td>
                            <td><?php
                                  $total_bdo = $bdo_loan+$sc_bdo_loan;
                                  echo number_format($total_bdo,2);
                            ?></td>
                        </tr>
                        <?php
                    }
                    else if ($sc_bdo_loan != 0 && $sc_bdo_loan != "") 
                        {
                         ?>
                         <tr>
                            <td></td>
                            <td></td>
                            <td>BDO Loan</td>
                            <td><?php
                                  $total_bdo = $bdo_loan+$sc_bdo_loan;
                                  echo number_format($total_bdo,2);
                            ?></td>
                        </tr>
                        <?php
                    }
                    else
                    {
                        ?>
                        
                    <?php
                }
                    ?>
                    <?php 
                        if ($pbb_loan != 0 && $pbb_loan != "") 
                        {
                         ?>
                         <tr>
                            <td></td>
                            <td></td>
                            <td>PBB Loan</td>
                            <td><?php
                             
                                  echo number_format($pbb_loan,2);
                            ?></td>
                        </tr>
                        <?php
                    }
                    else
                    {
                        ?>
                        
                    <?php
                }
                    ?>
                    <?php 
                        if ($lbp_loan != 0 && $lbp_loan != "") 
                        {
                         ?>
                         <tr>
                            <td></td>
                            <td></td>
                            <td>LBP Loan</td>
                            <td><?php
                                    $total_lbp = $lbp_loan+$sc_lbp_loan;
                                  echo number_format($total_lbp,2);
                            ?></td>
                        </tr>
                        <?php
                    }
                    else if ($sc_lbp_loan != 0 && $sc_lbp_loan != "") 
                        {
                         ?>
                         <tr>
                            <td></td>
                            <td></td>
                            <td>LBP Loan</td>
                            <td><?php
                                    $total_lbp = $lbp_loan+$sc_lbp_loan;
                                  echo number_format($total_lbp,2);
                            ?></td>
                        </tr>
                        <?php
                    }
                    else
                    {
                        ?>
                        
                    <?php
                }
                    ?>
                    <?php 
                        if ($abs_w_o_pay != 0 && $abs_w_o_pay != "") 
                        {
                         ?>
                         <tr>
                            <td></td>
                            <td></td>
                            <td>Absences W/O Pay</td>
                            <td><?php
                             
                                  echo number_format($abs_w_o_pay,2);
                            ?></td>
                        </tr>
                        <?php
                    }
                    else
                    {
                        ?>
                        
                    <?php
                }
                    ?>
                     <?php 
                        if ($sc_gsis_con_loan != 0 && $sc_gsis_con_loan != "") 
                        {
                         ?>
                         <tr>
                            <td></td>
                            <td></td>
                            <td>GSIS Consol Loan</td>
                            <td><?php
                             
                                  echo number_format($sc_gsis_con_loan,2);
                            ?></td>
                        </tr>
                        <?php
                    }
                    else
                    {
                        ?>
                        
                    <?php
                }
                    ?>
                     <?php 
                        if ($sc_gsis_eml != 0 && $sc_gsis_eml != "") 
                        {
                         ?>
                         <tr>
                            <td></td>
                            <td></td>
                            <td>GSIS EML</td>
                            <td><?php
                             
                                  echo number_format($sc_gsis_eml,2);
                            ?></td>
                        </tr>
                        <?php
                    }
                    else
                    {
                        ?>
                        
                    <?php
                }
                    ?>
                     <?php 
                        if ($sc_gsis_policy != 0 && $sc_gsis_policy != "") 
                        {
                         ?>
                         <tr>
                            <td></td>
                            <td></td>
                            <td>GSIS Policy</td>
                            <td><?php
                             
                                  echo number_format($sc_gsis_policy,2);
                            ?></td>
                        </tr>
                        <?php
                    }
                    else
                    {
                        ?>
                        
                    <?php
                }
                    ?>
                     
                     <?php 
                        if ($sc_gsis_mpl != 0 && $sc_gsis_mpl != "") 
                        {
                         ?>
                         <tr>
                            <td></td>
                            <td></td>
                            <td>GSIS MPL</td>
                            <td><?php
                             
                                  echo number_format($sc_gsis_mpl,2);
                            ?></td>
                        </tr>
                        <?php
                    }
                    else
                    {
                        ?>
                        
                    <?php
                }
                    ?>
                     <?php 
                        if ($sc_gsis_computer != 0 && $sc_gsis_computer != "") 
                        {
                         ?>
                         <tr>
                            <td></td>
                            <td></td>
                            <td>GSIS Computer Loan</td>
                            <td><?php
                             
                                  echo number_format($sc_gsis_computer,2);
                            ?></td>
                        </tr>
                        <?php
                    }
                    else
                    {
                        ?>
                        
                    <?php
                }
                    ?>
                     <?php 
                        if ($sc_pagibig_mpl != 0 && $sc_pagibig_mpl != "") 
                        {
                         ?>
                         <tr>
                            <td></td>
                            <td></td>
                            <td>Pag-ibig MPL</td>
                            <td><?php
                             
                                  echo number_format($sc_pagibig_mpl,2);
                            ?></td>
                        </tr>
                        <?php
                    }
                    else
                    {
                        ?>
                        
                    <?php
                }
                    ?>
                    <?php 
                        if ($o_amt != 0 && $o_amt != "") 
                        {
                         ?>
                         <tr>
                            <td></td>
                            <td></td>
                            <td><?php echo $label; ?></td>
                            <td><?php
                             
                                  echo number_format($o_amt,2);
                            ?></td>
                        </tr>
                        <?php
                    }
                    else
                    {
                        ?>
                        
                    <?php
                }
                    ?>
                     <?php 
                        if ($sc_pagibig_savings != 0 && $sc_pagibig_savings != "") 
                        {
                         ?>
                         <tr>
                            <td></td>
                            <td></td>
                            <td>Pag-ibig MP2 Savings</td>
                            <td><?php
                             
                                  echo number_format($sc_pagibig_savings,2);
                            ?></td>
                        </tr>
                        <?php
                    }
                    else
                    {
                        ?>
                        
                    <?php
                }
                    ?>
                    

                       
                        <tr class="border-top">
                            <th scope="row">Gross Pay</th>
                            <td><?php $gross_pay = $reg_salary+$pera1;
                            echo number_format($gross_pay, 2); ?></td>
                            <th scope="row">Total Deductions</th>
                            <td><?php 
                             $total_deduction_overall = $abs_w_o_pay+$life_insurrance+$pagibig_cont+$philhealth+$withholding_tax+$deped_prov_loan+$gsis_gfal+$gsis_help+$ucpb_loan+$eastwest_loan+$chinabank_loan+$csb_loan+$bdo_loan+$pbb_loan+$lbp_loan+$sc_gsis_con_loan+$sc_gsis_eml+$sc_gsis_policy+$sc_gsis_help+$sc_gsis_gfal+$sc_gsis_mpl+$sc_gsis_computer+$sc_pagibig_mpl+$sc_pagibig_savings+$sc_csb_loan+$sc_ucpb_loan+$sc_chinabank_loan+$sc_eastwest_loan+$sc_bdo_loan+$sc_lbp_loan+floatval($o_amt);
                            echo number_format($total_deduction_overall,2); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
            <div class="row" style="margin-top:-40px">
                <div class="col-md-4"> <br> <span class="fw-bold">1st Half Pay :<small class="ms-4"> <?php $first_net_amt_due_others = $first_net_amt_due-floatval($o_amt); echo  number_format($first_net_amt_due_others,2); ?></small></span> </div>
                <div class="col-md-4" style="margin-top:-20px"> <br> <span class="fw-bold">2nd Half Pay :<small class="ms-4">  <?php $sc_net_amt_due_others = $sc_net_amt_due-floatval($o_amt); echo number_format($sc_net_amt_due_others,2); ?></small></span> </div>
                <div class="col-md-4"> <br> <span class="fw-bold" style="font-size: 20px;">Net Pay :<small class="ms-4"><?php $net=$first_net_amt_due_others+$sc_net_amt_due_others;
                    echo number_format($net,2); ?></small></span> </div>
            </div>
            <div class="row" style="margin-top: 40px;">
                <div class="col-6">
                    <div class="d-flex flex-column mt-2">
                    <span class="fw-bolder">FEMIE KATE M. SUMILHIG</span> <span class="mt-2">ADAS III / Sr. Bookkeeper</span>
                </div>
                </div>
                <div class="col-6" >
                    <div class="d-flex flex-column mt-2" style="margin-left:200px">
                    <span class="fw-bolder">JADE L. VIDAL</span> <span class="mt-2">Admin Officer IV</span>
                    </div>
                </div>
            </div>
            

        </div>
    </div>
</div>
<script>
  window.addEventListener("load", window.print());
</script>
</body>
</html>
<?php
}
?>