
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="sweetalert.css">
        <script type="text/javascript" src="sweetalert-dev.js"></script>
    </head>
    

    <body>
        
    </body>

</html>
<?php
require_once 'connect.php';
$position_id= isset($_POST['position_idz'])? $_POST['position_idz']:"";
$user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
$position_name=$_POST['position_name'];
        $sql1 = "SELECT * FROM tbl_position WHERE position_name=?";
            $qry1 =$DbConnect->prepare($sql1);
            $qry1->bind_param("s",$position_name);
            $qry1->execute();
            $qry1->store_result();
            $qry1->fetch();
            if ($qry1->num_rows()>=1)
                {
                    err2();
                }
                else
                {
if (!empty($position_name))
{
    $sql = "UPDATE tbl_position SET position_name=?, user_id=? WHERE position_id=?";
    $qry =$DbConnect->prepare($sql);
    $qry->bind_param("sss",$position_name,$user_id,$position_id);
    if ($qry->execute())
    {
     succ();    
    }
}
else 
{
    err();
}
}

function succ()
        {
            echo '<script>
            swal({
                title: "Updated Successfully",
                type: "success",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "position.php ";
            });
            </script>';
        }
        function err()
        {
            echo '<script>
            swal({
                title: "Error!!...",
                type: "error",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "position.php ";
            });
            </script>';
        }
        function err2()
        {
            echo '<script>
            swal({
                title: "Cant Update this item. It might already exist in Position record",
                type: "warning",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "position.php ";
            });
            </script>';
        }
        ?>