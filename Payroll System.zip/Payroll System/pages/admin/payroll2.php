 <?php
include 'connect.php';
session_start();

if ($_SESSION['user_id'] ==!empty($user_id))
{
  
  header ('location:../index.php');
}
?>
  <?php
  require_once("connect.php");
  

  $user_id = $_SESSION['user_id'];
  $user_type = $_SESSION['user_type'];
  if ($user_type !== "Admin")
  {
     header ('location:logoutsession.php');
  }
  else
  {
  $sql= "SELECT user_id,username,password,fullname,user_type FROM tbl_user WHERE user_id=? AND user_type='Admin' ";
              
  $qry=$DbConnect->prepare($sql);
  $qry->bind_result($user_id,$username,$password,$fullname,$user_type);
  $qry->bind_param("s",$user_id);
  $qry->execute();

  while ($qry->fetch())
  { 
    ?>
  
<?php
}
}
  ?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>SNHS Payroll System</title>

  <!-- Google Font: Source Sans Pro -->
  
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" type="text/css" href="dataTables.bootstrap5.min.css">
  <link rel="stylesheet" type="text/css" href="fixedColumns.bootstrap5.min.css">
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <link rel="stylesheet" href="../../plugins/select2/css/select2.min.css">
  <link rel="stylesheet" href="../../plugins/select2-bootstrap4-theme/select2-bootstrap4.min.css">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
  <!-- Navbar -->
  <nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
      
    </ul>

    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Navbar Search -->
      <li class="nav-item">
        <a class="nav-link" data-widget="fullscreen" href="#" role="button">
          <i class="fas fa-expand-arrows-alt"></i>
        </a>
      </li>
    </ul>
  </nav>
  <!-- /.navbar -->

  <!-- Main Sidebar Container -->
   <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="payroll2.php" class="brand-link">
      <img src="../../dist/img/snhs.png" alt="" class="brand-image img-circle elevation-3" style="opacity: .8">
      <span class="brand-text font-weight-light">SNHS Payroll System</span>
    </a>

    <!-- Sidebar -->
   <div class="sidebar">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="../../dist/img/user.png" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="#" class="d-block"><?php echo $fullname; ?></a>
        </div>
      </div>

 

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item">
            <a href="dashboard.php" class="nav-link">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
          <li class="nav-item menu-open">
            <a href="payroll.php" class="nav-link active">
              <i class="nav-icon fas fa-money-bill-wave"></i>
              <p>
                Payroll
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="department.php" class="nav-link">
              <i class="nav-icon fas fa-building"></i>
              <p>
                Department
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="employee.php" class="nav-link">
              <i class="nav-icon fas fa-users"></i>
              <p>
                Employee
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="position.php" class="nav-link">
              <i class="nav-icon fas fa-user-tag"></i>
              <p>
                Position
              </p>
            </a>
          </li>
          
          <li class="nav-item">
            <a href="backup.php" class="nav-link">
              <i class="nav-icon fas fa-database"></i>
              <p>
                Backup Database
              </p>
            </a>
          </li>
          <li class="nav-item">
            <a href="logoutsession.php" class="nav-link">
              <i class="nav-icon fas fa-power-off"></i>
              <p>
                Logout
              </p>
            </a>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Payroll</h1>
             <div class="b" >
                <a href="payroll.php" ><button class="btn btn-default btn-md" style="background-color:#e9ecef;">1st half</button></a><a href="payroll2.php"><button class="btn bg-gradient-secondary btn-md" style="background-color:#e9ecef;">2nd half</button></a>
                </div>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Payroll</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-12">
            <div class="card">
              
              <!-- /.card-header -->
              <div class="card-body">
                <table id="example" class="table table-striped nowrap" style="width:100%">
        <thead>

            <tr>
                    <th width="5">Serial</th>
                    <th>Name</th>
                    <th>Position</th>
                    <th>Reg Wages</th>
                    <th>Amt Earned Period</th>
                    <th>PERA</th>
                    <th>Gross Amount</th>
                    <th>GSIS Consol</th>
                    <th>GSIS EML</th>
                    <th>GSIS Policy</th>
                    <th>GSIS H.E.L.P</th>
                    <th>GSIS GFAL</th>
                    <th>GSIS MPL</th>
                    <th>GSIS Computer</th>
                    <th>Pag-ibig MPL</th>
                    <th>Pag-ibig MP2 Savings</th>
                    <th>CSB Loan</th>
                    <th>UCPB Loan</th>
                    <th>Chinabank Loan</th>
                    <th>Eastwest Loan</th>
                    <th>BDO Loan</th>
                    <th>LBP Loan</th>
                    <th>total_deduction</th>
                    <th>Net amt. Due</th>
                    <th>Month & Year</th>
            </tr>
        </thead>
        <tbody>
           <?php include 'display_payroll_secondhalf.php'; ?>
        </tbody>
    </table>
                 
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
 <footer class="main-footer">
    <strong>Sagay National High School Payroll System <a href="">2023</a>.</strong>
    <div class="float-right d-none d-sm-inline-block">
      <b>Footer</b>
    </div>
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->

<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables  & Plugins -->
<script src="../../plugins/datatables/jquery.dataTables.min.js"></script>
<script src="../../plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="../../plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="../../plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="../../plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="../../plugins/pdfmake/vfs_fonts.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.html5.min.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.print.min.js"></script>
<script src="../../plugins/datatables-buttons/js/buttons.colVis.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<script src="../../plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<script type="text/javascript" src="jquery-3.5.1.js"></script>
<script type="text/javascript" src="jquery.dataTables.min.js"></script>
<script type="text/javascript" src="dataTables.bootstrap5.min.js"></script>
<script type="text/javascript" src="dataTables.fixedColumns.min.js"></script>
<script>
$(function () {
  bsCustomFileInput.init();
});
</script>
<script type="text/javascript">
  $(document).ready(function() {
    var table = $('#example').DataTable( {
        scrollY:        "200px",
        scrollX:        true,
        scrollCollapse: true,
        paging:         true,
        fixedColumns:   true
    } );
} );
</script>

</body>
</html>
