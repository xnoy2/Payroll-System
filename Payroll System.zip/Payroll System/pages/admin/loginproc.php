<!DOCTYPE html>
<html>
	<head>
		<title></title>
	</head>
			<link rel="stylesheet" type="text/css" href="sweetalert.css">
		<script type="text/javascript" src="sweetalert-dev.js"></script>
	<body>
	</body>
</html>
<?php
	session_start();
	require_once 'connect.php';

	$username=$_POST['username'];
	$password=md5($_POST['password']);

	if (empty($username) || empty($password))
	{
		header ('location:../../index.php');
	}
	else
	{
		$sql="SELECT user_id,user_type FROM tbl_user  WHERE username=? AND password=?";
		$qry=$DbConnect->prepare($sql);
		$qry->bind_param("ss",$username,$password);
		$qry->bind_result($user_id,$user_type);
		$qry->execute();
		$count=0;

		while ($qry->fetch()) 
		{
			$count++;
			$_SESSION['user_id'] = $user_id;
			$_SESSION['user_type'] = $user_type;
		}

		if ($count==1)
		{
			if ($user_type == "Admin")
			{
			header ('location:dashboard.php');
		}
		else
		{
			error1();
		}

		}
		else
		{
			error1();
		}
	}

	function error1()
		{
			echo '<script>
			swal({
				title: "Incorrect Username, Password",
				type: "error",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "../../index.php ";
			});
			</script>';
		}
	
	
?>