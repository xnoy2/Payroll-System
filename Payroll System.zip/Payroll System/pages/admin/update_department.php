
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="sweetalert.css">
        <script type="text/javascript" src="sweetalert-dev.js"></script>
    </head>
    

    <body>
        
    </body>

</html>
<?php
require_once 'connect.php';
$dept_id= isset($_POST['dept_idz'])? $_POST['dept_idz']:"";
$user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
$dept_name=$_POST['dept_name'];
        $sql1 = "SELECT * FROM tbl_department WHERE dept_name=?";
            $qry1 =$DbConnect->prepare($sql1);
            $qry1->bind_param("s",$dept_name);
            $qry1->execute();
            $qry1->store_result();
            $qry1->fetch();
            if ($qry1->num_rows()>=1)
                {
                    err2();
                }
                else
                {
if (!empty($dept_name))
{
    $sql = "UPDATE tbl_department SET dept_name=?, user_id=? WHERE dept_id=?";
    $qry =$DbConnect->prepare($sql);
    $qry->bind_param("sss",$dept_name,$user_id,$dept_id);
    if ($qry->execute())
    {
     succ();    
    }
}
else 
{
    err();
}
}

function succ()
        {
            echo '<script>
            swal({
                title: "Updated Successfully",
                type: "success",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "department.php ";
            });
            </script>';
        }
        function err()
        {
            echo '<script>
            swal({
                title: "Error!!...",
                type: "error",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "department.php ";
            });
            </script>';
        }
        function err2()
        {
            echo '<script>
            swal({
                title: "Cant Update this item. It might already exist in department record",
                type: "warning",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "department.php ";
            });
            </script>';
        }
        ?>