
 <!DOCTYPE html>
<html lang="en" dir="ltr">
    <head> 
        <meta charset="utf-8">
        <title>Import</title>
        <link rel="stylesheet" type="text/css" href="sweetalert.css">
        <script type="text/javascript" src="sweetalert-dev.js"></script>
    </head>
    <body>
    <?php
    require 'config.php';
if(isset($_POST["import"])){
    
            $fileName = $_FILES["excel"]["name"];
            $fileExtension = explode('.', $fileName);
      $fileExtension = strtolower(end($fileExtension));
            $newFileName = date("Y.m.d") . " - " . date("h.i.sa") . "." . $fileExtension;

            $targetDirectory = "uploads/" . $newFileName;
            move_uploaded_file($_FILES['excel']['tmp_name'], $targetDirectory);

            error_reporting(0);
            ini_set('display_errors', 0);

            require 'excelReader/excel_reader2.php';
            require 'excelReader/SpreadsheetReader.php';
 
      $reader = new SpreadsheetReader($targetDirectory);
            foreach($reader as $key => $row){
        $serial_no = $row[0];
        $name = $row[1];
        $position = $row[2];  
        $reg_salary  = $row[3];
        $amt_earned= $row[4];
        $pera = $row[5];
        $gross_amt = $row[6];
        $abs_w_o_pay = $row[7];
        $life_insurrance = $row[8];
        $pagibig_cont = $row[9];
        $philhealth = $row[10];
        $withholding_tax = $row[11];
        $deped_prov_loan = $row[12];
        $gsis_gfal = $row[13];
        $gsis_help = $row[14];
        $ucpb_loan = $row[15];
        $eastwest_loan = $row[16];
        $chinabank_loan = $row[17];
        $csb_loan = $row[18];
        $bdo_loan = $row[19];
        $pbb_loan = $row[20];
        $lbp_loan = $row[21];
        $first_total_deduc = $row[22];
        $first_net_amt_due = $row[23];
        $sc_gsis_con_loan = $row[24];
        $sc_gsis_eml=$row[25];
        $sc_gsis_policy=$row[26];
        $sc_gsis_help=$row[27];
        $sc_gsis_gfal=$row[28];
        $sc_gsis_mpl=$row[29];
        $sc_gsis_computer=$row[30];
        $sc_pagibig_mpl=$row[31];
        $sc_pagibig_savings=$row[32];
        $sc_csb_loan=$row[33];
        $sc_ucpb_loan=$row[34];
        $sc_chinabank_loan=$row[35];
        $sc_eastwest_loan=$row[36];
        $sc_bdo_loan=$row[37];
        $sc_lbp_loan=$row[38];
        $sc_total_deduction=$row[39];
        $sc_net_amt_due=$row[40];
        $month = $_POST['month'];
        $year = $_POST['year'];
        $count_print = 0;
        $date_printed = "";
        mysqli_query($conn, "INSERT INTO tbl_payroll VALUES('', '$serial_no', '$name', '$position', '$reg_salary', '$amt_earned', '$pera', '$gross_amt', '$abs_w_o_pay', '$life_insurrance', '$pagibig_cont', '$philhealth', '$withholding_tax', '$deped_prov_loan', '$gsis_gfal', '$gsis_help', '$ucpb_loan', '$eastwest_loan', '$chinabank_loan', '$csb_loan','$bdo_loan', '$pbb_loan', '$lbp_loan', '$first_total_deduc', '$first_net_amt_due','$sc_gsis_con_loan','$sc_gsis_eml','$sc_gsis_policy','$sc_gsis_help','$sc_gsis_gfal','$sc_gsis_mpl','$sc_gsis_computer','$sc_pagibig_mpl','$sc_pagibig_savings','$sc_csb_loan','$sc_ucpb_loan','$sc_chinabank_loan','$sc_eastwest_loan','$sc_bdo_loan','$sc_lbp_loan','$sc_total_deduction','$sc_net_amt_due','$month','$year', '$count_print','$date_printed')");
            }
                succ();
            }
              function succ()
                {
                    echo '<script>
                    swal({
                        title: "Imported Successfuly",
                        type: "success",
                        showCancelButton: false,
                        closeOnConfirm: true,
                    },
                    function ()
                    {
                        window.location.href = "payroll.php ";
                    });
                    </script>';
                }
?>
    </body>
</html>

