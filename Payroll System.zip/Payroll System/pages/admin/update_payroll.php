
<!DOCTYPE html>
<html>
    <head>
        <title></title>
        <link rel="stylesheet" type="text/css" href="sweetalert.css">
        <script type="text/javascript" src="sweetalert-dev.js"></script>
    </head>
    

    <body>
        
    </body>

</html>
<?php
require_once 'connect.php';

 $payroll_id= isset($_POST['idz'])? $_POST['idz']:"";
 $position=$_POST['position'];
$name=$_POST['name'];
 $reg_salary=$_POST['reg_salary'];
 $pera=$_POST['pera'];
 $abs_w_o_pay=$_POST['abs_w_o_pay'];
 $life_insurrance=$_POST['life_insurrance'];
 $pagibig_cont=$_POST['pagibig_cont'];
 $philhealth=$_POST['philhealth'];
 $withholding_tax=$_POST['withholding_tax'];
 $deped_prov_loan=$_POST['deped_prov_loan'];
 $gsis_gfal=$_POST['gsis_gfal'];
 $gsis_help=$_POST['gsis_help'];
 $ucpb_loan=$_POST['ucpb_loan'];
 $eastwest_loan=$_POST['eastwest_loan'];
 $chinabank_loan=$_POST['chinabank_loan'];
 $csb_loan=$_POST['csb_loan'];
 $bdo_loan=$_POST['bdo_loan'];
 $pbb_loan=$_POST['pbb_loan'];
 $lbp_loan=$_POST['lbp_loan'];
 $amt_earned = $reg_salary / 2;
 $gross_amt = $amt_earned+$pera;
 
if ($name!="" && $position!="" && $reg_salary!=="" && $pera!=="" && $abs_w_o_pay!=="" && $life_insurrance!=="" && $pagibig_cont!=="" &&  $philhealth!=="" && $deped_prov_loan!=="" && $withholding_tax!=="" &&  $gsis_gfal!=="" && $gsis_help!=="" &&  $ucpb_loan!=="" &&  $eastwest_loan!=="" &&  $chinabank_loan!=="" &&  $csb_loan!=="" &&  $bdo_loan!=="" &&  $pbb_loan!=="" &&  $lbp_loan!=="")
{
$first_total_deduc = $abs_w_o_pay+$life_insurrance+$pagibig_cont+$philhealth+$withholding_tax+$deped_prov_loan+$gsis_gfal+$gsis_help+$ucpb_loan+$eastwest_loan+$chinabank_loan+$csb_loan+$bdo_loan+$pbb_loan+$lbp_loan;
$first_net_amt_due = $gross_amt-$first_total_deduc;

    $sql = "UPDATE tbl_payroll SET name=?,position=?,reg_salary=?, amt_earned=?, pera=?, gross_amt=?, abs_w_o_pay=?, life_insurrance=?, pagibig_cont=?, philhealth=?, withholding_tax=?, deped_prov_loan=?, gsis_gfal=?, gsis_help=?, ucpb_loan=?, eastwest_loan=?,chinabank_loan=?, csb_loan=?, bdo_loan=?, pbb_loan=?, lbp_loan=?, first_total_deduc=?,first_net_amt_due=? WHERE payroll_id=?";
    $qry =$DbConnect->prepare($sql);
    $qry->bind_param("ssssssssssssssssssssssss",$name,$position,$reg_salary,$amt_earned,$pera,$gross_amt,$abs_w_o_pay,$life_insurrance,$pagibig_cont,$philhealth,$withholding_tax,$deped_prov_loan,$gsis_gfal,$gsis_help,$ucpb_loan,$eastwest_loan,$chinabank_loan,$csb_loan,$bdo_loan,$pbb_loan,$lbp_loan,$first_total_deduc, $first_net_amt_due, $payroll_id);
    if ($qry->execute())
    {
        succ();
    }
    else
    {
    err();
    }
}
else
{
    err2();
}
function succ()
        {
            echo '<script>
            swal({
                title: "Updated Successfully",
                type: "success",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "payroll.php ";
            });
            </script>';
        }
        function err()
        {
            echo '<script>
            swal({
                title: "Error!!...",
                type: "error",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "payroll.php ";
            });
            </script>';
        }
          function err2()
        {
            echo '<script>
            swal({
                title: "Error!!..missing require fields",
                type: "warning",
                showCancelButton: false,
                closeOnConfirm: true,
            },
            function ()
            {
                window.location.href = "payroll.php ";
            });
            </script>';
        }
        ?>