<!DOCTYPE html>
<html>
	<head>
		<title></title>
		<link rel="stylesheet" type="text/css" href="sweetalert.css">
		<script type="text/javascript" src="sweetalert-dev.js"></script>
	</head>
	

	<body>
		
	</body>

</html>

 <?php
	include ("connect.php");

	
	$user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
	$dept_id = $_POST['dept_id'];
	$position_id = $_POST['position_id'];
	$employee_id = $_POST['employee_id'];
	$fullname = $_POST['fullname'];
	$salary = $_POST['salary'];
			$sql1 = "SELECT * FROM tbl_employee WHERE employee_id=?";
			$qry1 =$DbConnect->prepare($sql1);
			$qry1->bind_param("s",$employee_id);
			$qry1->execute();
			$qry1->store_result();
			$qry1->fetch();
			if ($qry1->num_rows()<=0)
				{
	if (!empty($dept_id) && !empty($position_id))
		{
			$user_id= isset($_POST['user_idz'])? $_POST['user_idz']:"";
			$dept_id = $_POST['dept_id'];
			$position_id = $_POST['position_id'];
			$employee_id = $_POST['employee_id'];
			$fullname = $_POST['fullname'];
			$salary = $_POST['salary'];
			$sql="INSERT INTO tbl_employee (employee_id,fullname,dept_id,position_id,salary,user_id) VALUES (?,?,?,?,?,?)";
			$qry=$DbConnect->prepare($sql);
			$qry->bind_param("ssssss", $employee_id,$fullname,$dept_id,$position_id,$salary,$user_id);
			if ($qry->execute())
			{
				 succ();

			}
			else
			{
			error2();
			}
		}
		else
		{
			error2();
		}
				}
				else
				{
					err2();
				}
		function succ()
		{
			echo '<script>
			swal({
				title: "Added Successfully",
				type: "success",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "employee.php ";
			});
			</script>';
		}
		function error2()
		{
			echo '<script>
			swal({
				title: "Error!!!..",
				type: "error",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "employee.php ";
			});
			</script>';
		}
	
				function err2()
		{
			echo '<script>
			swal({
				title: "Employee ID Already Exist",
				type: "error",
				showCancelButton: false,
				closeOnConfirm: true,
			},
			function ()
			{
				window.location.href = "employee.php ";
			});
			</script>';
		}
	
?>