

<!DOCTYPE html>
<html>
<head>
    <title>SNHS Payroll System</title>
</head>
<style type="text/css">
    :root {
    --main-bg-color: #ecf0f3;
}

* {
    box-sizing: border-box;
}

html,
body {
    height: 100%;
    width: 100%;
    display: flex;
    background-color: var(--main-bg-color);
}

.container {
    margin: auto;
    padding: 2rem;
    border-radius: 2.5rem;
    background-color: var(--main-bg-color);
    box-shadow: 7px 7px 20px #002142,
                            -7px -7px 20px #002142;
}

.logo {
    display: flex;
    width: 100%;
    margin-bottom: 3rem;
}

.logo__circle {
    margin: auto;
    width: 6.25rem;
    height: 6.25rem;
    display: flex;
    border-radius: 9999px;
    background-color: #E9D985;
/*  border: 1px solid black; */
    box-shadow: 
        0px 0px 2px #5F5F5F,
        0px 0px 0px 5px #ECF0F3,
        8px 8px 15px #A7AAAF,
        -8px -8px 15px #FFFFFF;
}

.logo__svg {
    margin: auto;
    width: calc(6.25rem / 3);
    height: calc(6.25rem / 3);
    opacity: 0.4;
}

.form__group {
    width: 18rem;
    margin-bottom: 2rem;
    position: relative;
}

.form__icon {
    position: absolute;
    left: 0;
    height: 100%;
    display: flex;
    width: 3rem;
}

.form__icon svg {
    margin: auto;
    weight: 0.75rem;
    height: 0.75rem;
    opacity: 0.35;
}

.form__control {
    appearance: none;
    border: none;
    background-color: transparent;
    font-size: 0.875rem;
    padding: 1rem;
    padding-left: 2.5rem;
    width: 100%;
    border-radius: 1.5rem;
    box-shadow: 
        inset 8px 8px 8px #CBCED1,
        inset -8px -8px 8px #FFFFFF;
}

.form__control:focus {
    outline: none;
    box-shadow: 
        inset 8px 8px 8px #c5c5c5,
        inset -8px -8px 8px #FFFFFF;
}

.form__control:focus::placeholder {
    color: #d3d3d3;
    letter-spacing: 0.15em;
}

.form__control::placeholder {
    color: #CCCCCC;
}

.form__button {
    text-transform: uppercase;
    letter-spacing: 0.15em;
    border: none;
    font-size: 0.875rem;
    color: #FFFFFF;
    background-color: #2e43bc;
    width: 100%;
    display: block;
    padding: 0.875rem 1rem;
    border-radius: 1.5rem;
    box-shadow: 
        3px 3px 8px #B1B1B1,
        -3px -3px 8px #FFFFFF;
}

.form__button:focus {
    outline: none;
    box-shadow: 
        3px 3px 20px #B1B1B1,
        -3px -3px 20px #FFFFFF;
}

.form__button:hover {
    opacity: 0.85;
}
body {
  background-image: url('dist/img/bg4.jpg');
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: 100% 100%;
  background-position: center;
  }
</style>

<body>

<div class="container" style="background-color: #ffffff;">
    <center>
        <h4 style="color: #240895">SNHS Payroll System</h4>
        <h1 style="margin-top: -5%; color: #240895">Login Form</h1></center>
    <div class="logo" style="place-items: center;">
            <img src="dist/img/snhs.png" alt="Avatar" style="border-radius:3%; display: block; margin-right: auto; margin-left: auto;" width="70" >
    </div>
    <form class="form" method="post" action="pages/admin/loginproc.php">
        <div class="form__group">
            <div class="form__icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M5 5a5 5 0 0 1 10 0v2A5 5 0 0 1 5 7V5zM0 16.68A19.9 19.9 0 0 1 10 14c3.64 0 7.06.97 10 2.68V20H0v-3.32z"/></svg></div>
            <input class="form__control" name="username" type="text" placeholder="Enter Username..">
        </div>
        <div class="form__group">
            <div class="form__icon"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"><path d="M4 8V6a6 6 0 1 1 12 0v2h1a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2v-8c0-1.1.9-2 2-2h1zm5 6.73V17h2v-2.27a2 2 0 1 0-2 0zM7 6v2h6V6a3 3 0 0 0-6 0z"/></svg></div>
            <input class="form__control" name="password" type="password" placeholder="Enter Password..">
        </div>
        <div>
            <button class="form__button" type="submit" style="background-color: #240895">
                Login
            </button>
        </div>
    </form>
</div>
</body>
</html>